# -*- coding: utf-8 -*-
# ============================================================
# Fichier : parser_bridge.py
# Projet  : SGN - Systeme de Gestion des Notes
# Role    : Communication entre l'interface Python et le compilateur C
#           et exportation des resultats en CSV et TXT.
# Auteur  : Equipe du projet SGN
# Date    : 21/11/2026
# ============================================================

import csv
import json
import subprocess
from pathlib import Path


# Chemin du projet SGN
DOSSIER_PROJET = Path(__file__).resolve().parent.parent

# Chemin du compilateur C
COMPILATEUR = DOSSIER_PROJET / "src" / "sgn_parser"


class ErreurCompilateur(Exception):
    """Erreur lors de l'execution du compilateur SGN."""


def analyser_texte(contenu):
    """Execute le compilateur C et recupere son resultat JSON."""

    if not COMPILATEUR.is_file():
        raise ErreurCompilateur(
            "Compilateur introuvable.\n"
            "Veuillez executer make dans le dossier src."
        )

    try:
        resultat = subprocess.run(
            [str(COMPILATEUR)],
            input=contenu,
            text=True,
            capture_output=True,
            encoding="utf-8",
            errors="replace",
            cwd=str(DOSSIER_PROJET),
            timeout=30,
            check=False
        )

    except subprocess.TimeoutExpired as erreur:
        raise ErreurCompilateur(
            "Le compilateur a depasse le temps autorise."
        ) from erreur

    except OSError as erreur:
        raise ErreurCompilateur(
            f"Impossible de lancer le compilateur : {erreur}"
        ) from erreur

    if not resultat.stdout.strip():
        raise ErreurCompilateur(
            "Le compilateur n'a retourne aucun resultat JSON.\n"
            + resultat.stderr
        )

    try:
        donnees = json.loads(resultat.stdout)

    except json.JSONDecodeError as erreur:
        raise ErreurCompilateur(
            "Le resultat du compilateur n'est pas un JSON valide.\n"
            f"Detail : {erreur}\n"
            f"Sortie du programme : {resultat.stdout[:500]}"
        ) from erreur

    return donnees, resultat.returncode, resultat.stderr


def formater_moyenne(valeur):
    """Formate une moyenne pour l'affichage dans un fichier TXT."""

    if valeur is None:
        return "—"

    return f"{float(valeur):.2f}"


def formater_moyenne_csv(valeur):
    """Formate une moyenne avec une virgule decimale pour Excel en francais."""

    if valeur is None:
        return ""

    return f"{float(valeur):.2f}".replace(".", ",")


def exporter_csv(chemin, donnees):
    """
    Exporte un tableau recapitulatif propre : une ligne par etudiant.

    Les six colonnes de semestre permettent de regrouper les niveaux L1,
    L2 et L3 dans un seul tableau, sans melanger les semestres.
    Le point-virgule est utilise comme separateur pour Excel en francais.
    """

    colonnes = [
        "Annee academique",
        "Matricule",
        "Nom",
        "Prenom",
        "Niveau",
        "Moyenne S1 (/20)",
        "Moyenne S2 (/20)",
        "Moyenne S3 (/20)",
        "Moyenne S4 (/20)",
        "Moyenne S5 (/20)",
        "Moyenne S6 (/20)",
        "Moyenne annuelle (/20)",
        "Rang",
        "Mention",
        "Decision"
    ]

    annee = donnees.get("annee", "")

    with open(
        chemin,
        "w",
        encoding="utf-8-sig",
        newline=""
    ) as fichier:

        writer = csv.DictWriter(
            fichier,
            fieldnames=colonnes,
            delimiter=";",
            quotechar='"',
            quoting=csv.QUOTE_MINIMAL,
            lineterminator="\r\n"
        )

        writer.writeheader()

        for niveau in donnees.get("niveaux", []):
            for etudiant in niveau.get("etudiants", []):

                # Preparer les colonnes de tous les semestres.
                moyennes_semestres = {
                    f"Moyenne S{numero} (/20)": ""
                    for numero in range(1, 7)
                }

                for semestre in etudiant.get("semestres", []):
                    identifiant = semestre.get("id", "")

                    if identifiant in {
                        "S1", "S2", "S3", "S4", "S5", "S6"
                    }:
                        nom_colonne = f"Moyenne {identifiant} (/20)"
                        moyennes_semestres[nom_colonne] = (
                            formater_moyenne_csv(semestre.get("moyenne"))
                        )

                ligne = {
                    "Annee academique": annee,
                    "Matricule": etudiant.get("matricule", ""),
                    "Nom": etudiant.get("nom", ""),
                    "Prenom": etudiant.get("prenom", ""),
                    "Niveau": niveau.get("niveau", ""),
                    **moyennes_semestres,
                    "Moyenne annuelle (/20)": formater_moyenne_csv(
                        etudiant.get("moyenne_annuelle")
                    ),
                    "Rang": (
                        etudiant.get("rang")
                        if etudiant.get("rang") is not None
                        else ""
                    ),
                    "Mention": etudiant.get("mention") or "",
                    "Decision": etudiant.get("decision") or ""
                }

                writer.writerow(ligne)


def exporter_txt(chemin, donnees):
    """Exporte les resultats detailles au format TXT."""

    with open(chemin, "w", encoding="utf-8", newline="") as fichier:

        fichier.write("SYSTEME DE GESTION DES NOTES\n")
        fichier.write("============================\n\n")

        fichier.write(
            f"Annee academique : {donnees.get('annee', '')}\n"
        )

        for niveau in donnees.get("niveaux", []):

            fichier.write(
                f"\nRESULTATS DU NIVEAU {niveau.get('niveau', '')}\n"
            )
            fichier.write("-" * 60 + "\n")

            for etudiant in niveau.get("etudiants", []):

                fichier.write("\n" + "=" * 60 + "\n")
                fichier.write(
                    f"Matricule : {etudiant.get('matricule', '')}\n"
                )
                fichier.write(
                    f"Nom       : {etudiant.get('nom', '')}\n"
                )
                fichier.write(
                    f"Prenom    : {etudiant.get('prenom', '')}\n"
                )
                fichier.write(f"Niveau    : {niveau.get('niveau', '')}\n")

                fichier.write("\nDETAIL DES SEMESTRES\n")
                fichier.write("--------------------\n")

                for semestre in etudiant.get("semestres", []):
                    fichier.write(
                        f"\n{semestre.get('id', 'Semestre')} "
                        f"- Moyenne : "
                        f"{formater_moyenne(semestre.get('moyenne'))}/20\n"
                    )

                    fichier.write(
                        f"{'Module':<30} {'Coef.':>8} {'Note /20':>12}\n"
                    )
                    fichier.write("-" * 54 + "\n")

                    for module in semestre.get("modules", []):
                        nom_module = str(module.get("nom", ""))
                        coefficient = module.get("coef", "")
                        note = formater_moyenne(module.get("note"))
                        fichier.write(
                            f"{nom_module:<30} {str(coefficient):>8} "
                            f"{note:>12}\n"
                        )

                fichier.write("\nRECAPITULATIF ANNUEL\n")
                fichier.write("--------------------\n")
                fichier.write(
                    "Moyenne annuelle : "
                    + formater_moyenne(
                        etudiant.get("moyenne_annuelle")
                    )
                    + "/20\n"
                )
                fichier.write(
                    f"Rang              : {etudiant.get('rang') or '—'}\n"
                )
                fichier.write(
                    f"Mention           : {etudiant.get('mention') or '—'}\n"
                )
                fichier.write(
                    f"Decision          : {etudiant.get('decision') or '—'}\n"
                )

        erreurs = donnees.get("erreurs", [])
        fichier.write("\n\nDIAGNOSTICS\n")
        fichier.write("===========\n")

        if not erreurs:
            fichier.write("Aucune erreur detectee.\n")
        else:
            for erreur in erreurs:
                fichier.write(
                    f"\n[{erreur.get('type', 'inconnue')}] "
                    f"Ligne {erreur.get('ligne', 0)} : "
                    f"{erreur.get('message', '')}\n"
                )
