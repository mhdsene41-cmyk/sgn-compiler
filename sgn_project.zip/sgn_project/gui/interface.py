import os
import re
import shutil
import subprocess
import sys
import threading
import tkinter as tk

from tkinter import ttk, filedialog, messagebox

from pathlib import Path

from parser_bridge import (

    analyser_texte,

    exporter_csv,

    exporter_txt,

    ErreurCompilateur

)


def ouvrir_fichier_exporte(chemin):
    """Ouvre le fichier exporte avec l'application associee au systeme."""

    fichier = Path(chemin).resolve()

    if not fichier.is_file():
        return False

    try:
        # Windows natif : Excel, Bloc-notes ou autre application associee.
        if sys.platform == "win32":
            os.startfile(str(fichier))
            return True

        # WSL : demander a Windows d'ouvrir le fichier avec son application par defaut.
        version_noyau = Path("/proc/version")
        sous_wsl = (
            sys.platform.startswith("linux")
            and version_noyau.exists()
            and any(
                mot in version_noyau.read_text(encoding="utf-8", errors="ignore").lower()
                for mot in ("microsoft", "wsl")
            )
        )

        if sous_wsl:
            commande_wslpath = shutil.which("wslpath")
            commande_windows = shutil.which("cmd.exe") or shutil.which("cmd")

            if commande_wslpath and commande_windows:
                conversion = subprocess.run(
                    [commande_wslpath, "-w", str(fichier)],
                    capture_output=True,
                    text=True,
                    check=True,
                    timeout=10
                )
                chemin_windows = conversion.stdout.strip()

                if chemin_windows:
                    subprocess.Popen(
                        [commande_windows, "/c", "start", "", chemin_windows],
                        stdin=subprocess.DEVNULL,
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                        close_fds=True
                    )
                    return True

        # Linux : application associee (LibreOffice, lecteur texte, etc.).
        if sys.platform.startswith("linux"):
            commande = shutil.which("xdg-open")
            if commande:
                subprocess.Popen(
                    [commande, str(fichier)],
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    start_new_session=True
                )
                return True

        # macOS : application associee au type de fichier.
        if sys.platform == "darwin":
            commande = shutil.which("open")
            if commande:
                subprocess.Popen(
                    [commande, str(fichier)],
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    start_new_session=True
                )
                return True

    except (OSError, subprocess.SubprocessError):
        return False

    return False

# =====================================================

# PALETTE GRAPHIQUE

# =====================================================

COULEURS = {
    "fond": "#F3F7F4",
    "blanc": "#FFFFFF",
    "sidebar": "#EEF3EF",
    "sidebar_secondaire": "#E1EEE5",
    "bleu": "#66849A",
    "bleu_survol": "#54768D",
    "bleu_clair": "#E8F0F4",
    "texte": "#26352D",
    "secondaire": "#718078",
    "bordure": "#DCE6DF",
    "vert": "#258458",
    "vert_clair": "#E1F2E7",
    "rouge": "#C44F4F",
    "rouge_clair": "#FBE9E7",
    "orange": "#B77932",
    "orange_clair": "#FFF1DD",
    "editeur": "#F8FAF8",
    "gouttiere": "#EDF2EE",
    "code": "#34443B"
}

# =====================================================

# CLASSE PRINCIPALE

# =====================================================

class SGNApplication:

    def __init__(self, fenetre):

        self.fenetre = fenetre

        self.fenetre.title(

            "SGN - Gestion des notes"

        )

        self.fenetre.geometry("1360x700")

        self.fenetre.minsize(1180, 650)

        self.fenetre.configure(

            bg=COULEURS["fond"]

        )

        self.fichier_actuel = None

        self.donnees = None

        self.modifie = False

        self.analyse_en_cours = False

        self.details_etudiants = {}

        self._configurer_style()

        self._construire_interface()

        self.fenetre.protocol(

            "WM_DELETE_WINDOW",

            self._fermer_application

        )

        self.fenetre.bind(

            "<Control-o>",

            lambda event: self.ouvrir_fichier()

        )

        self.fenetre.bind(

            "<Control-s>",

            lambda event: self.enregistrer_fichier()

        )

        self.fenetre.bind(

            "<F5>",

            lambda event: self.lancer_analyse()

        )

    # =================================================

    # STYLE

    # =================================================

    def _configurer_style(self):

        style = ttk.Style()

        style.theme_use("clam")

        style.configure(

            "SGN.Treeview",

            background=COULEURS["blanc"],

            foreground=COULEURS["texte"],

            fieldbackground=COULEURS["blanc"],

            rowheight=29,

            font=("DejaVu Sans", 9),

            borderwidth=0

        )

        style.configure(

            "SGN.Treeview.Heading",

            background="#EAF2EC",

            foreground=COULEURS["texte"],

            font=("DejaVu Sans", 8, "bold"),

            padding=7,

            relief="flat"

        )

        style.map(

            "SGN.Treeview",

            background=[

                ("selected", COULEURS["bleu_clair"])

            ],

            foreground=[

                ("selected", COULEURS["texte"])

            ]

        )

        style.configure(

            "Vertical.TScrollbar",

            background="#DCE6DF",

            troughcolor="#F3F7F4",

            borderwidth=0,

            arrowsize=12

        )

        style.configure(

            "Horizontal.TScrollbar",

            background="#DCE6DF",

            troughcolor="#F3F7F4",

            borderwidth=0,

            arrowsize=12

        )

    # =================================================

    # OUTILS GRAPHIQUES

    # =================================================

    def _creer_carte(self, parent, padding=14):

        return tk.Frame(

            parent,

            bg=COULEURS["blanc"],

            padx=padding,

            pady=padding,

            highlightbackground=COULEURS["bordure"],

            highlightthickness=1

        )

    def _creer_bouton(

        self,

        parent,

        texte,

        commande,

        type_bouton="secondaire"

    ):

        if type_bouton == "principal":

            fond = COULEURS["vert"]

            texte_couleur = "#FFFFFF"

            survol = "#1F7049"

        elif type_bouton == "danger":

            fond = COULEURS["rouge_clair"]

            texte_couleur = COULEURS["rouge"]

            survol = "#F7DAD7"

        else:

            fond = "#FFFFFF"

            texte_couleur = COULEURS["texte"]

            survol = "#EAF2EC"

        bouton = tk.Button(

            parent,

            text=texte,

            command=commande,

            bg=fond,

            fg=texte_couleur,

            activebackground=survol,

            activeforeground=texte_couleur,

            relief="flat",

            borderwidth=0,

            cursor="hand2",

            font=("DejaVu Sans", 9, "bold"),

            padx=11,

            pady=7

        )

        bouton.bind(

            "<Enter>",

            lambda event: bouton.configure(

                bg=survol

            )

        )

        bouton.bind(

            "<Leave>",

            lambda event: bouton.configure(

                bg=fond

            )

        )

        return bouton

    # =================================================

    # CONSTRUCTION GENERALE

    # =================================================

    def _construire_interface(self):

        conteneur = tk.Frame(

            self.fenetre,

            bg=COULEURS["fond"]

        )

        conteneur.pack(

            fill=tk.BOTH,

            expand=True

        )

        self._construire_sidebar(conteneur)

        zone_principale = tk.Frame(

            conteneur,

            bg=COULEURS["fond"]

        )

        zone_principale.pack(

            side=tk.LEFT,

            fill=tk.BOTH,

            expand=True

        )

        self._construire_zone_principale(

            zone_principale

        )

    # =================================================

    # BARRE LATERALE

    # =================================================

    def _construire_sidebar(self, parent):
        """Barre laterale avec les diagnostics toujours visibles."""
        sidebar = tk.Frame(
            parent,
            bg=COULEURS["sidebar"],
            width=270
        )
        sidebar.pack(side=tk.LEFT, fill=tk.Y)
        sidebar.pack_propagate(False)

        # Les informations fixes restent en bas de la barre laterale.
        version = tk.Frame(
            sidebar,
            bg=COULEURS["sidebar_secondaire"],
            padx=11,
            pady=10
        )
        version.pack(side=tk.BOTTOM, fill=tk.X, padx=10, pady=(7, 11))

        tk.Label(
            version,
            text="PROJET UNIVERSITAIRE",
            bg=COULEURS["sidebar_secondaire"],
            fg=COULEURS["vert"],
            font=("DejaVu Sans", 8, "bold")
        ).pack(anchor=tk.W)

        tk.Label(
            version,
            text="Licence 3 Informatique",
            bg=COULEURS["sidebar_secondaire"],
            fg=COULEURS["texte"],
            font=("DejaVu Sans", 9, "bold")
        ).pack(anchor=tk.W, pady=(4, 0))

        environnement = tk.Frame(
            sidebar,
            bg=COULEURS["sidebar"],
            padx=16,
            pady=9
        )
        environnement.pack(side=tk.BOTTOM, fill=tk.X)

        tk.Label(
            environnement,
            text="ENVIRONNEMENT",
            bg=COULEURS["sidebar"],
            fg=COULEURS["secondaire"],
            font=("DejaVu Sans", 8, "bold")
        ).pack(anchor=tk.W)

        tk.Label(
            environnement,
            text="FLEX 2.6.4  •  BISON 3.8\nC  •  PYTHON  •  TKINTER",
            justify=tk.LEFT,
            bg=COULEURS["sidebar"],
            fg=COULEURS["texte"],
            font=("DejaVu Sans", 8)
        ).pack(anchor=tk.W, pady=(5, 0))

        # Identite de l'application en haut.
        logo_zone = tk.Frame(sidebar, bg=COULEURS["sidebar"])
        logo_zone.pack(fill=tk.X, padx=16, pady=(20, 15))

        logo = tk.Label(
            logo_zone,
            text="S",
            bg=COULEURS["vert"],
            fg="#FFFFFF",
            font=("DejaVu Sans", 18, "bold"),
            width=2,
            height=1
        )
        logo.pack(side=tk.LEFT, padx=(0, 9))

        identite = tk.Frame(logo_zone, bg=COULEURS["sidebar"])
        identite.pack(side=tk.LEFT, anchor=tk.CENTER)

        tk.Label(
            identite,
            text="SGN",
            bg=COULEURS["sidebar"],
            fg=COULEURS["texte"],
            font=("DejaVu Sans", 10, "bold")
        ).pack(anchor=tk.W)

        tk.Label(
            identite,
            text="GESTION DES NOTES",
            bg=COULEURS["sidebar"],
            fg=COULEURS["secondaire"],
            font=("DejaVu Sans", 7, "bold")
        ).pack(anchor=tk.W)

        tk.Frame(
            sidebar,
            bg=COULEURS["bordure"],
            height=1
        ).pack(fill=tk.X, padx=15, pady=(0, 12))

        tk.Label(
            sidebar,
            text="SUIVI DE L'ANALYSE",
            bg=COULEURS["sidebar"],
            fg=COULEURS["vert"],
            font=("DejaVu Sans", 8, "bold")
        ).pack(anchor=tk.W, padx=16, pady=(0, 5))

        # Ce panneau occupe l'espace libre de la barre laterale.
        self._construire_diagnostics(sidebar)

    # =================================================

    # ZONE PRINCIPALE

    # =================================================

    def _construire_zone_principale(self, parent):

        contenu = tk.Frame(

            parent,

            bg=COULEURS["fond"],

            padx=12,

            pady=7

        )

        contenu.pack(

            fill=tk.BOTH,

            expand=True

        )

        self._construire_entete(contenu)

        self._construire_barre_actions(contenu)

        self._construire_statistiques(contenu)

        # La zone de travail recupere toute la hauteur liberee par les diagnostics.
        self._construire_pied_page(contenu)
        self._construire_espace_travail(contenu)

    # =================================================

    # ENTETE

    # =================================================

    def _construire_entete(self, parent):

        entete = tk.Frame(

            parent,

            bg=COULEURS["fond"]

        )

        entete.pack(

            fill=tk.X,

            pady=(0, 6)

        )

        gauche = tk.Frame(

            entete,

            bg=COULEURS["fond"]

        )

        gauche.pack(side=tk.LEFT)

        tk.Label(

            gauche,

            text="TABLEAU DE BORD",

            bg=COULEURS["fond"],

            fg=COULEURS["bleu"],

            font=("DejaVu Sans", 8, "bold")

        ).pack(anchor=tk.W)

        tk.Label(

            gauche,

            text="Gestion des notes",

            bg=COULEURS["fond"],

            fg=COULEURS["texte"],

            font=("DejaVu Sans", 21, "bold")

        ).pack(anchor=tk.W, pady=(3, 1))

        tk.Label(

            gauche,

            text="Analysez vos fichiers et consultez les résultats universitaires.",

            bg=COULEURS["fond"],

            fg=COULEURS["secondaire"],

            font=("DejaVu Sans", 9)

        ).pack(anchor=tk.W)

        self.badge_statut = tk.Label(

            entete,

            text="● PRET",

            bg=COULEURS["vert_clair"],

            fg=COULEURS["vert"],

            font=("DejaVu Sans", 9, "bold"),

            padx=13,

            pady=8

        )

        self.badge_statut.pack(

            side=tk.RIGHT,

            anchor=tk.N,

            pady=10

        )

    # =================================================

    # BARRE DES ACTIONS

    # =================================================

    def _construire_barre_actions(self, parent):

        barre = self._creer_carte(

            parent,

            padding=8

        )

        barre.pack(

            fill=tk.X,

            pady=(0, 7)

        )

        self._creer_bouton(

            barre,

            "+ Nouveau",

            self.nouveau_fichier

        ).pack(

            side=tk.LEFT,

            padx=4

        )

        self._creer_bouton(

            barre,

            "Ouvrir .sgn",

            self.ouvrir_fichier

        ).pack(

            side=tk.LEFT,

            padx=4

        )

        self._creer_bouton(

            barre,

            "Enregistrer",

            self.enregistrer_fichier

        ).pack(

            side=tk.LEFT,

            padx=4

        )

        tk.Frame(

            barre,

            bg=COULEURS["bordure"],

            width=1,

            height=30

        ).pack(

            side=tk.LEFT,

            padx=10

        )

        self.bouton_analyser = self._creer_bouton(

            barre,

            "▶  Analyser",

            self.lancer_analyse,

            "principal"

        )

        self.bouton_analyser.pack(

            side=tk.LEFT,

            padx=4

        )

        self.bouton_csv = self._creer_bouton(

            barre,

            "Exporter CSV",

            self.exporter_fichier_csv

        )

        self.bouton_csv.pack(

            side=tk.LEFT,

            padx=4

        )

        self.bouton_txt = self._creer_bouton(

            barre,

            "Exporter TXT",

            self.exporter_fichier_txt

        )

        self.bouton_txt.pack(

            side=tk.LEFT,

            padx=4

        )

        self.bouton_csv.configure(

            state=tk.DISABLED

        )

        self.bouton_txt.configure(

            state=tk.DISABLED

        )

        self.label_fichier = tk.Label(

            barre,

            text="Aucun fichier ouvert",

            bg=COULEURS["blanc"],

            fg=COULEURS["secondaire"],

            font=("DejaVu Sans", 8)

        )

        self.label_fichier.pack(

            side=tk.RIGHT,

            padx=10

        )

    # =================================================

    # CARTES STATISTIQUES

    # =================================================

    def _construire_statistiques(self, parent):

        zone = tk.Frame(

            parent,

            bg=COULEURS["fond"]

        )

        zone.pack(

            fill=tk.X,

            pady=(0, 7)

        )

        zone.grid_columnconfigure(

            0,

            weight=1

        )

        zone.grid_columnconfigure(

            1,

            weight=1

        )

        zone.grid_columnconfigure(

            2,

            weight=1

        )

        zone.grid_columnconfigure(

            3,

            weight=1

        )

        configurations = [

            ("ÉTUDIANTS", "0", "Étudiants analysés", "#66849A"),

            ("NIVEAUX", "0", "L1, L2 et L3", "#718078"),

            ("MOYENNE GÉNÉRALE", "—", "Moyenne des étudiants", "#258458"),

            ("ERREURS", "0", "Erreurs détectées", "#C44F4F")

        ]

        self.statistiques = {}

        for index, configuration in enumerate(configurations):

            titre, valeur, description, couleur = configuration

            carte = self._creer_carte(

                zone,

                padding=6

            )

            carte.grid(

                row=0,

                column=index,

                sticky="nsew",

                padx=5

            )

            tk.Label(

                carte,

                text=titre,

                bg=COULEURS["blanc"],

                fg=COULEURS["secondaire"],

                font=("DejaVu Sans", 8, "bold")

            ).pack(anchor=tk.W)

            label_valeur = tk.Label(

                carte,

                text=valeur,

                bg=COULEURS["blanc"],

                fg=couleur,

                font=("DejaVu Sans", 19, "bold")

            )

            label_valeur.pack(

                anchor=tk.W,

                pady=(5, 0)

            )

            tk.Label(

                carte,

                text=description,

                bg=COULEURS["blanc"],

                fg=COULEURS["secondaire"],

                font=("DejaVu Sans", 8)

            ).pack(anchor=tk.W)

            self.statistiques[titre] = label_valeur

    def _actualiser_statistiques(self, donnees):

        if donnees is None:

            etudiants = []

            nombres_niveaux = 0

            nombre_erreurs = 0

        else:

            niveaux = donnees.get("niveaux", [])

            etudiants = [

                etudiant

                for niveau in niveaux

                for etudiant in niveau.get("etudiants", [])

            ]

            nombres_niveaux = len(niveaux)

            nombre_erreurs = len(

                donnees.get("erreurs", [])

            )

        moyennes = [

            e.get("moyenne_annuelle")

            for e in etudiants

            if e.get("moyenne_annuelle") is not None

        ]

        if moyennes:

            moyenne_generale = (

                sum(moyennes) / len(moyennes)

            )

            moyenne_texte = f"{moyenne_generale:.2f}/20"

        else:

            moyenne_texte = "—"

        self.statistiques["ÉTUDIANTS"].configure(

            text=str(len(etudiants))

        )

        self.statistiques["NIVEAUX"].configure(

            text=str(nombres_niveaux)

        )

        self.statistiques["MOYENNE GÉNÉRALE"].configure(

            text=moyenne_texte

        )

        self.statistiques["ERREURS"].configure(

            text=str(nombre_erreurs)

        )

    # =================================================

    # ESPACE DE TRAVAIL

    # =================================================

    def _construire_espace_travail(self, parent):
        """Place l'éditeur et le tableau côte à côte, avec priorité au tableau."""
        espace = tk.PanedWindow(
            parent,
            orient=tk.HORIZONTAL,
            bg=COULEURS["fond"],
            sashwidth=6,
            sashrelief=tk.FLAT,
            bd=0,
            opaqueresize=True
        )
        espace.pack(
            fill=tk.BOTH,
            expand=True,
            pady=(0, 7)
        )

        carte_editeur = self._creer_carte(espace, padding=8)
        carte_resultats = self._creer_carte(espace, padding=8)

        # Environ un tiers pour l'éditeur et deux tiers pour le tableau.
        espace.add(
            carte_editeur,
            minsize=275,
            width=325,
            stretch="never"
        )
        espace.add(
            carte_resultats,
            minsize=560,
            stretch="always"
        )

        self._construire_editeur(carte_editeur)
        self._construire_tableau(carte_resultats)

        # L'editeur reste compact et le tableau recoit la majeure partie de l'espace.
        self.fenetre.after(220, lambda: espace.sash_place(0, 330, 0))

    def _construire_editeur(self, parent):

        entete = tk.Frame(

            parent,

            bg=COULEURS["blanc"]

        )

        entete.pack(

            fill=tk.X,

            pady=(0, 10)

        )

        tk.Label(

            entete,

            text="Éditeur du fichier SGN",

            bg=COULEURS["blanc"],

            fg=COULEURS["texte"],

            font=("DejaVu Sans", 11, "bold")

        ).pack(side=tk.LEFT)

        tk.Label(

            entete,

            text=".sgn",

            bg=COULEURS["bleu_clair"],

            fg=COULEURS["bleu"],

            font=("DejaVu Sans", 8, "bold"),

            padx=8,

            pady=4

        ).pack(side=tk.RIGHT)

        # Zone de texte

        zone = tk.Frame(

            parent,

            bg=COULEURS["editeur"]

        )

        zone.pack(

            fill=tk.BOTH,

            expand=True

        )

        self.numeros_lignes = tk.Text(

            zone,

            width=4,

            height=14,

            padx=8,

            pady=7,

            font=("DejaVu Sans Mono", 9),

            bg=COULEURS["gouttiere"],

            fg="#64748B",

            relief=tk.FLAT,

            state=tk.DISABLED,

            wrap=tk.NONE,

            takefocus=False

        )

        self.numeros_lignes.grid(

            row=0,

            column=0,

            sticky="ns"

        )

        self.editeur = tk.Text(

            zone,

            padx=12,

            pady=7,

            font=("DejaVu Sans Mono", 9),

            height=14,

            bg=COULEURS["editeur"],

            fg=COULEURS["code"],

            insertbackground="#258458",

            selectbackground="#D8EADF",

            selectforeground="#26352D",

            relief=tk.FLAT,

            wrap=tk.NONE,

            undo=True,

            tabs=("32p",)

        )

        self.editeur.grid(

            row=0,

            column=1,

            sticky="nsew"

        )

        self.scroll_vertical = ttk.Scrollbar(

            zone,

            orient=tk.VERTICAL,

            command=self._faire_defiler_editeur

        )

        self.scroll_vertical.grid(

            row=0,

            column=2,

            sticky="ns"

        )

        self.scroll_horizontal = ttk.Scrollbar(

            zone,

            orient=tk.HORIZONTAL,

            command=self.editeur.xview

        )

        self.scroll_horizontal.grid(

            row=1,

            column=1,

            sticky="ew"

        )

        self.editeur.configure(

            yscrollcommand=self._synchroniser_defilement

        )

        zone.rowconfigure(0, weight=1)

        zone.columnconfigure(1, weight=1)

        # Coloration syntaxique

        self.editeur.tag_configure(

            "motcle",

            foreground="#66849A"

        )

        self.editeur.tag_configure(

            "chaine",

            foreground="#258458"

        )

        self.editeur.tag_configure(

            "nombre",

            foreground="#B77932"

        )

        self.editeur.tag_configure(

            "commentaire",

            foreground="#87938C",

            font=("DejaVu Sans Mono", 9, "italic")

        )

        self.editeur.tag_raise("chaine")

        self.editeur.tag_raise("commentaire")

        self.editeur.bind(

            "<KeyRelease>",

            self._editeur_modifie

        )

        self.editeur.bind(

            "<<Paste>>",

            lambda event: self.fenetre.after(

                50,

                self._actualiser_gouttiere

            )

        )

        self._actualiser_gouttiere()

    def _synchroniser_defilement(self, debut, fin):

        self.scroll_vertical.set(

            debut,

            fin

        )

        self.numeros_lignes.yview_moveto(

            float(debut)

        )

    def _faire_defiler_editeur(self, *arguments):

        self.editeur.yview(*arguments)

        self.numeros_lignes.yview(*arguments)

    def _actualiser_gouttiere(self):

        nombre_lignes = int(

            self.editeur.index("end-1c").split(".")[0]

        )

        contenu = "\n".join(

            str(numero)

            for numero in range(1, nombre_lignes + 1)

        )

        self.numeros_lignes.configure(

            state=tk.NORMAL

        )

        self.numeros_lignes.delete(

            "1.0",

            tk.END

        )

        self.numeros_lignes.insert(

            "1.0",

            contenu

        )

        self.numeros_lignes.configure(

            state=tk.DISABLED

        )

        self.numeros_lignes.yview_moveto(

            self.editeur.yview()[0]

        )

    def _colorier_syntaxe(self):

        contenu = self.editeur.get(

            "1.0",

            "end-1c"

        )

        tags = [

            "motcle",

            "chaine",

            "nombre",

            "commentaire"

        ]

        for tag in tags:

            self.editeur.tag_remove(

                tag,

                "1.0",

                tk.END

            )

        motifs = [

            (

                "motcle",

                r"\b(ANNEE|NIVEAU|ETUDIANT|MATRICULE|NOM|PRENOM|SEMESTRE|MODULE|COEF|NOTE|L1|L2|L3|S1|S2|S3|S4|S5|S6)\b"

            ),

            (

                "nombre",

                r"\b\d+(?:\.\d+)?\b"

            ),

            (

                "chaine",

                r'"[^"\n]*"'

            ),

            (

                "commentaire",

                r"--[^\n]*"

            )

        ]

        for nom_tag, motif in motifs:

            for correspondance in re.finditer(

                motif,

                contenu

            ):

                debut = f"1.0+{correspondance.start()}c"

                fin = f"1.0+{correspondance.end()}c"

                self.editeur.tag_add(

                    nom_tag,

                    debut,

                    fin

                )

    def _editeur_modifie(self, event=None):

        self.modifie = True

        self._actualiser_gouttiere()

        self._colorier_syntaxe()

        self._changer_statut(

            "Modifications non enregistrees",

            "modifie"

        )

    # =================================================

    # TABLEAU DES RESULTATS

    # =================================================

    def _construire_tableau(self, parent):
        entete = tk.Frame(parent, bg=COULEURS["blanc"])
        entete.pack(fill=tk.X, pady=(0, 7))

        tk.Label(
            entete,
            text="Résultats des étudiants",
            bg=COULEURS["blanc"],
            fg=COULEURS["texte"],
            font=("DejaVu Sans", 10, "bold")
        ).pack(side=tk.LEFT)

        self.nombre_resultats = tk.Label(
            entete,
            text="0 étudiant",
            bg=COULEURS["vert_clair"],
            fg=COULEURS["vert"],
            font=("DejaVu Sans", 8, "bold"),
            padx=9,
            pady=4
        )
        self.nombre_resultats.pack(side=tk.RIGHT)

        # Deux colonnes distinctes pour les deux semestres du niveau.
        # Cela évite une longue colonne « Semestres » qui oblige à défiler.
        colonnes = (
            "matricule",
            "etudiant",
            "niveau",
            "semestre1",
            "semestre2",
            "moyenne",
            "rang",
            "mention",
            "decision"
        )

        cadre_tableau = tk.Frame(parent, bg=COULEURS["blanc"])
        cadre_tableau.pack(fill=tk.BOTH, expand=True)

        self.tableau = ttk.Treeview(
            cadre_tableau,
            columns=colonnes,
            show="headings",
            style="SGN.Treeview",
            height=14
        )

        titres = {
            "matricule": "Matricule",
            "etudiant": "Étudiant",
            "niveau": "Niveau",
            "semestre1": "S1 /20",
            "semestre2": "S2 /20",
            "moyenne": "Moy. /20",
            "rang": "Rang",
            "mention": "Mention",
            "decision": "Décision"
        }

        # Largeurs calculées pour afficher toutes les informations en même temps.
        largeurs = {
            "matricule": 96,
            "etudiant": 120,
            "niveau": 52,
            "semestre1": 70,
            "semestre2": 70,
            "moyenne": 72,
            "rang": 48,
            "mention": 82,
            "decision": 74
        }

        for colonne in colonnes:
            self.tableau.heading(colonne, text=titres[colonne])
            self.tableau.column(
                colonne,
                width=largeurs[colonne],
                minwidth=largeurs[colonne],
                anchor=tk.W if colonne in ("matricule", "etudiant") else tk.CENTER,
                stretch=False
            )

        barre_verticale = ttk.Scrollbar(
            cadre_tableau,
            orient=tk.VERTICAL,
            command=self.tableau.yview
        )
        self.tableau.configure(yscrollcommand=barre_verticale.set)

        self.tableau.grid(row=0, column=0, sticky="nsew")
        barre_verticale.grid(row=0, column=1, sticky="ns")
        cadre_tableau.rowconfigure(0, weight=1)
        cadre_tableau.columnconfigure(0, weight=1)

        self.tableau.tag_configure(
            "admis",
            foreground="#258458",
            background="#F0F8F2"
        )
        self.tableau.tag_configure(
            "ajourne",
            foreground="#C44F4F",
            background="#FDF3F1"
        )
        self.tableau.tag_configure(
            "normal",
            foreground=COULEURS["texte"],
            background=COULEURS["blanc"]
        )

        self.tableau.bind("<Double-1>", self._ouvrir_details_selection)

    def _vider_tableau(self):

        for element in self.tableau.get_children():

            self.tableau.delete(element)

        self.details_etudiants.clear()

    def _remplir_tableau(self, donnees):
        self._vider_tableau()
        total = 0

        for niveau in donnees.get("niveaux", []):
            nom_niveau = niveau.get("niveau", "")

            for etudiant in niveau.get("etudiants", []):
                valeurs_semestres = ["—", "—"]

                for index, semestre in enumerate(etudiant.get("semestres", [])[:2]):
                    moyenne_semestre = semestre.get("moyenne")
                    moyenne_texte = (
                        f"{moyenne_semestre:.2f}"
                        if moyenne_semestre is not None
                        else "—"
                    )
                    identifiant_semestre = semestre.get("id", f"S{index + 1}")
                    valeurs_semestres[index] = f"{identifiant_semestre} : {moyenne_texte}"

                moyenne_annuelle = etudiant.get("moyenne_annuelle")
                moyenne_affichage = (
                    f"{moyenne_annuelle:.2f}"
                    if moyenne_annuelle is not None
                    else "—"
                )

                rang = etudiant.get("rang")
                rang_affichage = str(rang) if rang is not None else "—"
                decision = etudiant.get("decision") or "—"

                if decision == "Admis":
                    etiquette = "admis"
                elif decision == "Ajourné":
                    etiquette = "ajourne"
                else:
                    etiquette = "normal"

                valeurs = (
                    etudiant.get("matricule", ""),
                    f"{etudiant.get('nom', '')} {etudiant.get('prenom', '')}".strip(),
                    nom_niveau,
                    valeurs_semestres[0],
                    valeurs_semestres[1],
                    moyenne_affichage,
                    rang_affichage,
                    etudiant.get("mention") or "—",
                    decision
                )

                identifiant = self.tableau.insert(
                    "",
                    tk.END,
                    values=valeurs,
                    tags=(etiquette,)
                )
                self.details_etudiants[identifiant] = {
                    "niveau": nom_niveau,
                    "etudiant": etudiant
                }
                total += 1

        self.nombre_resultats.configure(text=f"{total} étudiant(s)")

    def _ouvrir_details_selection(self, event=None):
        """Ouvre le releve de notes detaille de l'etudiant selectionne."""

        selection = self.tableau.selection()
        if not selection:
            return

        identifiant = selection[0]
        informations = self.details_etudiants.get(identifiant)
        if informations is None:
            return

        etudiant = informations["etudiant"]
        niveau = informations["niveau"]
        annee = (self.donnees or {}).get("annee", "")

        # La fenetre reprend la palette claire de l'application principale.
        bulletin = tk.Toplevel(self.fenetre)
        bulletin.title("Relevé de note - SGN")
        bulletin.configure(bg=COULEURS["fond"])
        bulletin.transient(self.fenetre)
        bulletin.resizable(True, True)

        # Adapter le bulletin a la resolution de l'ecran pour eviter
        # que le tableau, le recapitulatif ou le bouton Fermer soient coupes.
        bulletin.update_idletasks()
        largeur_ecran = bulletin.winfo_screenwidth()
        hauteur_ecran = bulletin.winfo_screenheight()
        largeur = min(980, max(760, largeur_ecran - 80))
        hauteur = min(760, max(600, hauteur_ecran - 80))
        x = max(0, (largeur_ecran - largeur) // 2)
        y = max(0, (hauteur_ecran - hauteur) // 2)
        bulletin.geometry(f"{largeur}x{hauteur}+{x}+{y}")
        bulletin.minsize(min(760, largeur), min(600, hauteur))

        def moyenne_texte(valeur):
            if valeur is None:
                return "—"
            try:
                return f"{float(valeur):.2f}".replace(".", ",")
            except (TypeError, ValueError):
                return str(valeur)

        def creer_carte(parent, titre, valeur, couleur=None):
            carte = tk.Frame(
                parent,
                bg=COULEURS["blanc"],
                padx=12,
                pady=8,
                highlightbackground=COULEURS["bordure"],
                highlightthickness=1
            )
            tk.Label(
                carte,
                text=titre.upper(),
                bg=COULEURS["blanc"],
                fg=COULEURS["secondaire"],
                font=("DejaVu Sans", 8, "bold")
            ).pack(anchor=tk.W)
            tk.Label(
                carte,
                text=valeur,
                bg=COULEURS["blanc"],
                fg=couleur or COULEURS["texte"],
                font=("DejaVu Sans", 11, "bold")
            ).pack(anchor=tk.W, pady=(5, 0))
            return carte

        # En-tete du bulletin.
        bandeau = tk.Frame(bulletin, bg=COULEURS["vert"], padx=22, pady=12)
        bandeau.pack(fill=tk.X)

        tk.Label(
            bandeau,
            text="SGN  |  SYSTÈME DE GESTION DES NOTES",
            bg=COULEURS["vert"],
            fg="#EAF7EF",
            font=("DejaVu Sans", 9, "bold")
        ).pack(anchor=tk.W)
        tk.Label(
            bandeau,
            text="RELEVÉ DE NOTE",
            bg=COULEURS["vert"],
            fg="#FFFFFF",
            font=("DejaVu Sans", 18, "bold")
        ).pack(anchor=tk.W, pady=(4, 1))
        tk.Label(
            bandeau,
            text=f"Année académique : {annee or 'Non renseignée'}",
            bg=COULEURS["vert"],
            fg="#EAF7EF",
            font=("DejaVu Sans", 9)
        ).pack(anchor=tk.W)

        contenu = tk.Frame(bulletin, bg=COULEURS["fond"], padx=18, pady=11)
        contenu.pack(fill=tk.BOTH, expand=True)

        # Identite de l'etudiant, presentee comme sur un releve universitaire.
        identite = tk.Frame(
            contenu,
            bg=COULEURS["blanc"],
            padx=14,
            pady=10,
            highlightbackground=COULEURS["bordure"],
            highlightthickness=1
        )
        identite.pack(fill=tk.X, pady=(0, 9))
        identite.columnconfigure(0, weight=2)
        identite.columnconfigure(1, weight=1)
        identite.columnconfigure(2, weight=1)

        nom_complet = " ".join(
            str(part).strip()
            for part in (etudiant.get("prenom", ""), etudiant.get("nom", ""))
            if str(part).strip()
        ) or "Étudiant non renseigné"

        champs_identite = [
            ("NOM ET PRÉNOM", nom_complet, 0),
            ("MATRICULE", etudiant.get("matricule") or "—", 1),
            ("NIVEAU", niveau or "—", 2),
        ]
        for titre, valeur, colonne in champs_identite:
            bloc = tk.Frame(identite, bg=COULEURS["blanc"])
            bloc.grid(row=0, column=colonne, sticky="ew", padx=(0, 12))
            tk.Label(
                bloc,
                text=titre,
                bg=COULEURS["blanc"],
                fg=COULEURS["secondaire"],
                font=("DejaVu Sans", 8, "bold")
            ).pack(anchor=tk.W)
            tk.Label(
                bloc,
                text=str(valeur),
                bg=COULEURS["blanc"],
                fg=COULEURS["texte"],
                font=("DejaVu Sans", 10, "bold"),
                wraplength=330,
                justify=tk.LEFT
            ).pack(anchor=tk.W, pady=(4, 0))

        tk.Label(
            contenu,
            text="DÉTAIL DES NOTES PAR SEMESTRE",
            bg=COULEURS["fond"],
            fg=COULEURS["texte"],
            font=("DejaVu Sans", 10, "bold")
        ).pack(anchor=tk.W, pady=(0, 5))

        # Tableau de type bulletin : une ligne par module et une ligne de moyenne
        # pour chaque semestre. La barre verticale permet les longues listes.
        cadre_tableau = tk.Frame(
            contenu,
            bg=COULEURS["blanc"],
            highlightbackground=COULEURS["bordure"],
            highlightthickness=1
        )
        cadre_tableau.pack(fill=tk.BOTH, expand=True)

        style_bulletin = ttk.Style(bulletin)
        style_bulletin.configure(
            "Bulletin.Treeview",
            background=COULEURS["blanc"],
            fieldbackground=COULEURS["blanc"],
            foreground=COULEURS["texte"],
            rowheight=28,
            font=("DejaVu Sans", 9),
            borderwidth=0
        )
        style_bulletin.configure(
            "Bulletin.Treeview.Heading",
            background="#EAF2EC",
            foreground=COULEURS["texte"],
            font=("DejaVu Sans", 9, "bold"),
            padding=9,
            relief="flat"
        )

        colonnes = ("semestre", "module", "coefficient", "note")
        tableau_bulletin = ttk.Treeview(
            cadre_tableau,
            columns=colonnes,
            show="headings",
            style="Bulletin.Treeview",
            height=6
        )
        entetes = {
            "semestre": "Semestre",
            "module": "Matière / Module",
            "coefficient": "Coefficient",
            "note": "Note / 20"
        }
        largeurs = {
            "semestre": 110,
            "module": 470,
            "coefficient": 130,
            "note": 130
        }
        for colonne in colonnes:
            tableau_bulletin.heading(colonne, text=entetes[colonne])
            tableau_bulletin.column(
                colonne,
                width=largeurs[colonne],
                minwidth=85 if colonne != "module" else 180,
                stretch=(colonne == "module"),
                anchor=tk.W if colonne == "module" else tk.CENTER
            )

        scroll_bulletin = ttk.Scrollbar(
            cadre_tableau,
            orient=tk.VERTICAL,
            command=tableau_bulletin.yview
        )
        tableau_bulletin.configure(yscrollcommand=scroll_bulletin.set)
        tableau_bulletin.grid(row=0, column=0, sticky="nsew")
        scroll_bulletin.grid(row=0, column=1, sticky="ns")
        cadre_tableau.rowconfigure(0, weight=1)
        cadre_tableau.columnconfigure(0, weight=1)

        tableau_bulletin.tag_configure(
            "section",
            background="#EAF2EC",
            foreground=COULEURS["vert"],
            font=("DejaVu Sans", 9, "bold")
        )
        tableau_bulletin.tag_configure(
            "module_pair",
            background="#FFFFFF",
            foreground=COULEURS["texte"]
        )
        tableau_bulletin.tag_configure(
            "module_impair",
            background="#F7FAF8",
            foreground=COULEURS["texte"]
        )
        tableau_bulletin.tag_configure(
            "moyenne_semestre",
            background="#F0F6F1",
            foreground=COULEURS["vert"],
            font=("DejaVu Sans", 9, "bold")
        )

        semestres = etudiant.get("semestres", [])
        numero_ligne = 0
        for semestre in semestres:
            identifiant_semestre = semestre.get("id", "Semestre")
            tableau_bulletin.insert(
                "",
                tk.END,
                values=(identifiant_semestre, "DÉTAIL DES MODULES", "", ""),
                tags=("section",)
            )

            modules = semestre.get("modules", [])
            if not modules:
                tableau_bulletin.insert(
                    "",
                    tk.END,
                    values=(identifiant_semestre, "Aucun module renseigné", "—", "—"),
                    tags=("module_pair",)
                )
            else:
                for module in modules:
                    numero_ligne += 1
                    note = module.get("note")
                    note_affichee = moyenne_texte(note)
                    coefficient = module.get("coef")
                    tableau_bulletin.insert(
                        "",
                        tk.END,
                        values=(
                            identifiant_semestre,
                            module.get("nom", "Module sans nom"),
                            coefficient if coefficient is not None else "—",
                            note_affichee
                        ),
                        tags=("module_pair" if numero_ligne % 2 == 0 else "module_impair",)
                    )

            moyenne_semestre = moyenne_texte(semestre.get("moyenne"))
            tableau_bulletin.insert(
                "",
                tk.END,
                values=(
                    "",
                    f"MOYENNE DU SEMESTRE {identifiant_semestre}",
                    "",
                    f"{moyenne_semestre} / 20"
                ),
                tags=("moyenne_semestre",)
            )

        if not semestres:
            tableau_bulletin.insert(
                "",
                tk.END,
                values=("—", "Aucun semestre renseigné", "—", "—")
            )

        # Synthese des resultats en bas du bulletin.
        tk.Label(
            contenu,
            text="RÉCAPITULATIF ACADÉMIQUE",
            bg=COULEURS["fond"],
            fg=COULEURS["texte"],
            font=("DejaVu Sans", 10, "bold")
        ).pack(anchor=tk.W, pady=(9, 5))

        synthese = tk.Frame(contenu, bg=COULEURS["fond"])
        synthese.pack(fill=tk.X)
        for colonne in range(4):
            synthese.columnconfigure(colonne, weight=1, uniform="resume")

        moyenne_annuelle = moyenne_texte(etudiant.get("moyenne_annuelle"))
        rang = etudiant.get("rang")
        rang_texte = str(rang) if rang is not None else "—"
        mention = etudiant.get("mention") or "—"
        decision = etudiant.get("decision") or "—"
        couleur_decision = (
            COULEURS["vert"] if decision == "Admis" else
            COULEURS["rouge"] if decision == "Ajourné" else COULEURS["texte"]
        )

        resume = [
            ("Moyenne annuelle", f"{moyenne_annuelle} / 20", COULEURS["vert"]),
            ("Rang dans le niveau", rang_texte, COULEURS["texte"]),
            ("Mention", mention, COULEURS["texte"]),
            ("Décision", decision, couleur_decision),
        ]
        for colonne, (titre, valeur, couleur) in enumerate(resume):
            carte = creer_carte(synthese, titre, valeur, couleur)
            carte.grid(row=0, column=colonne, sticky="nsew", padx=(0 if colonne == 0 else 6, 0))

        pied = tk.Frame(contenu, bg=COULEURS["fond"])
        pied.pack(fill=tk.X, pady=(9, 0))
        tk.Label(
            pied,
            text="Bulletin généré automatiquement par SGN Desktop.",
            bg=COULEURS["fond"],
            fg=COULEURS["secondaire"],
            font=("DejaVu Sans", 8)
        ).pack(side=tk.LEFT)

        bouton_fermer = tk.Button(
            pied,
            text="Fermer",
            command=bulletin.destroy,
            bg=COULEURS["vert"],
            fg="#FFFFFF",
            activebackground="#1F7049",
            activeforeground="#FFFFFF",
            relief=tk.FLAT,
            bd=0,
            cursor="hand2",
            font=("DejaVu Sans", 9, "bold"),
            padx=22,
            pady=8
        )
        bouton_fermer.pack(side=tk.RIGHT, pady=(0, 2))

        bulletin.grab_set()
        bulletin.focus_set()
        tableau_bulletin.focus_set()
    # =================================================

    # ZONE DES DIAGNOSTICS

    # =================================================

    def _construire_diagnostics(self, parent):
        """Affiche les erreurs dans la barre laterale gauche."""
        carte = tk.Frame(
            parent,
            bg=COULEURS["blanc"],
            padx=8,
            pady=8,
            highlightbackground=COULEURS["bordure"],
            highlightthickness=1
        )
        carte.pack(
            fill=tk.BOTH,
            expand=True,
            padx=10,
            pady=(0, 10)
        )

        entete = tk.Frame(carte, bg=COULEURS["blanc"])
        entete.pack(fill=tk.X, pady=(0, 7))

        tk.Label(
            entete,
            text="Diagnostics et erreurs",
            bg=COULEURS["blanc"],
            fg=COULEURS["texte"],
            font=("DejaVu Sans", 9, "bold")
        ).pack(anchor=tk.W)

        self.label_nombre_erreurs = tk.Label(
            entete,
            text="0 erreur(s)",
            bg=COULEURS["vert_clair"],
            fg=COULEURS["vert"],
            font=("DejaVu Sans", 8, "bold"),
            padx=7,
            pady=3
        )
        self.label_nombre_erreurs.pack(anchor=tk.W, pady=(5, 0))

        zone = tk.Frame(carte, bg=COULEURS["blanc"])
        zone.pack(fill=tk.BOTH, expand=True)

        self.zone_erreurs = tk.Text(
            zone,
            height=10,
            width=26,
            wrap=tk.WORD,
            font=("DejaVu Sans Mono", 8),
            bg="#F7FAF8",
            fg=COULEURS["texte"],
            relief=tk.FLAT,
            state=tk.DISABLED,
            padx=7,
            pady=7,
            spacing1=2,
            spacing3=3
        )

        scroll = ttk.Scrollbar(
            zone,
            orient=tk.VERTICAL,
            command=self.zone_erreurs.yview
        )
        self.zone_erreurs.configure(yscrollcommand=scroll.set)

        self.zone_erreurs.pack(
            side=tk.LEFT,
            fill=tk.BOTH,
            expand=True
        )
        scroll.pack(side=tk.RIGHT, fill=tk.Y)

        self.zone_erreurs.tag_configure(
            "succes",
            foreground=COULEURS["vert"]
        )
        self.zone_erreurs.tag_configure(
            "lexicale",
            foreground=COULEURS["rouge"]
        )
        self.zone_erreurs.tag_configure(
            "syntaxique",
            foreground=COULEURS["orange"]
        )
        self.zone_erreurs.tag_configure(
            "semantique",
            foreground=COULEURS["bleu"]
        )
        self.zone_erreurs.tag_configure(
            "technique",
            foreground=COULEURS["secondaire"]
        )
        self.zone_erreurs.tag_configure(
            "explication",
            foreground=COULEURS["texte"]
        )

        self._afficher_erreurs([])

    @staticmethod
    def _nom_element_syntaxique(element):
        """Traduit les tokens Bison en termes plus faciles a comprendre."""

        element = element.strip()

        descriptions = {
            "T_STRING": "une chaine de caracteres",
            "T_ENTIER": "un nombre entier",
            "T_REEL": "un nombre reel",
            "T_ANNEE": "le mot-cle ANNEE",
            "T_NIVEAU": "le mot-cle NIVEAU",
            "T_ETUDIANT": "le mot-cle ETUDIANT",
            "T_MATRICULE": "le champ MATRICULE",
            "T_NOM": "le champ NOM",
            "T_PRENOM": "le champ PRENOM",
            "T_SEMESTRE": "le mot-cle SEMESTRE",
            "T_MODULE": "le mot-cle MODULE",
            "T_COEF": "le mot-cle COEF",
            "T_NOTE": "le mot-cle NOTE",
            "T_L1": "l'identifiant de niveau L1",
            "T_L2": "l'identifiant de niveau L2",
            "T_L3": "l'identifiant de niveau L3",
            "T_S1": "l'identifiant de semestre S1",
            "T_S2": "l'identifiant de semestre S2",
            "T_S3": "l'identifiant de semestre S3",
            "T_S4": "l'identifiant de semestre S4",
            "T_S5": "l'identifiant de semestre S5",
            "T_S6": "l'identifiant de semestre S6",
            "':'": "le separateur « : »",
            "'{'": "l'accolade ouvrante « { »",
            "'}'": "l'accolade fermante « } »",
            "$end": "la fin du fichier",
            "end of file": "la fin du fichier"
        }

        if element in descriptions:
            return descriptions[element]

        if element.startswith("T_"):
            return f"le symbole {element[2:]}"

        return f"l'element {element}"

    @classmethod
    def _expliquer_erreur_syntaxique(cls, message):
        """Construit une explication francaise a partir du message Bison."""

        correspondance = re.search(
            r"unexpected (.+?)(?:,\s*expecting (.+))?$",
            message
        )

        if not correspondance:
            return (
                "La structure du fichier ne respecte pas la grammaire "
                "attendue. Verifiez l'ordre des mots-cles et des symboles."
            )

        element_trouve = cls._nom_element_syntaxique(
            correspondance.group(1)
        )
        element_attendu = correspondance.group(2)

        if not element_attendu:
            return (
                f"Le compilateur a rencontre {element_trouve} a un endroit "
                "ou cet element n'est pas autorise."
            )

        element_attendu = element_attendu.removeprefix("one of: ")
        choix_attendus = re.split(r"\s+or\s+", element_attendu)
        choix_traduits = [
            cls._nom_element_syntaxique(choix)
            for choix in choix_attendus
        ]

        if len(choix_traduits) == 1:
            attente = choix_traduits[0]
        else:
            attente = "l'un des elements suivants : " + ", ".join(
                choix_traduits
            )

        return (
            f"Le compilateur a rencontre {element_trouve}, alors qu'il "
            f"attendait {attente}."
        )

    def _afficher_erreurs(self, erreurs, diagnostic=""):
        self.zone_erreurs.configure(state=tk.NORMAL)
        self.zone_erreurs.delete("1.0", tk.END)

        if not erreurs:
            self.zone_erreurs.insert(
                tk.END,
                "✓  Aucune erreur detectee. Le fichier SGN est valide.\n",
                "succes"
            )
            couleur = COULEURS["vert_clair"]
            texte_badge = COULEURS["vert"]

        else:
            for erreur in erreurs:
                type_erreur = erreur.get("type", "inconnue")
                ligne = erreur.get("ligne", 0)
                message = erreur.get("message", "Erreur inconnue")
                numero = str(ligne) if ligne else "non precisee"

                if type_erreur == "syntaxique":
                    explication = self._expliquer_erreur_syntaxique(message)

                    self.zone_erreurs.insert(
                        tk.END,
                        f"[SYNTAXIQUE] Ligne {numero}\n",
                        "syntaxique"
                    )
                    self.zone_erreurs.insert(
                        tk.END,
                        f"  Explication : {explication}\n",
                        "explication"
                    )
                    self.zone_erreurs.insert(
                        tk.END,
                        f"  Detail technique : {message}\n\n",
                        "technique"
                    )
                else:
                    etiquette = (
                        type_erreur
                        if type_erreur in (
                            "lexicale",
                            "semantique"
                        )
                        else "technique"
                    )
                    self.zone_erreurs.insert(
                        tk.END,
                        f"[{type_erreur.upper()}] Ligne {numero} : "
                        f"{message}\n\n",
                        etiquette
                    )

            couleur = COULEURS["rouge_clair"]
            texte_badge = COULEURS["rouge"]

        if diagnostic.strip():
            self.zone_erreurs.insert(
                tk.END,
                "\nDiagnostic technique :\n" + diagnostic,
                "technique"
            )

        self.zone_erreurs.configure(state=tk.DISABLED)

        nombre = len(erreurs)
        self.label_nombre_erreurs.configure(
            text=f"{nombre} erreur(s)",
            bg=couleur,
            fg=texte_badge
        )

    # =================================================

    # STATUT

    # =================================================

    def _construire_pied_page(self, parent):

        self.message_statut = tk.StringVar(

            value="Application prete."

        )

        tk.Label(

            parent,

            textvariable=self.message_statut,

            bg=COULEURS["fond"],

            fg=COULEURS["secondaire"],

            font=("DejaVu Sans", 8),

            anchor=tk.W

        ).pack(

            side=tk.BOTTOM,

            fill=tk.X,

            pady=(0, 1)

        )

    def _changer_statut(self, texte, niveau="normal"):

        self.message_statut.set(texte)

        configurations = {

            "normal": (

                "● PRET",

                COULEURS["vert_clair"],

                COULEURS["vert"]

            ),

            "succes": (

                "● ANALYSE REUSSIE",

                COULEURS["vert_clair"],

                COULEURS["vert"]

            ),

            "erreur": (

                "● ERREURS DETECTEES",

                COULEURS["rouge_clair"],

                COULEURS["rouge"]

            ),

            "modifie": (

                "● MODIFIE",

                COULEURS["orange_clair"],

                COULEURS["orange"]

            ),

            "analyse": (

                "● ANALYSE EN COURS",

                COULEURS["bleu_clair"],

                COULEURS["bleu"]

            )

        }

        badge, fond, couleur = configurations.get(

            niveau,

            configurations["normal"]

        )

        self.badge_statut.configure(

            text=badge,

            bg=fond,

            fg=couleur

        )

    # =================================================

    # GESTION DES FICHIERS

    # =================================================

    def _confirmer_modifications(self):

        if not self.modifie:

            return True

        reponse = messagebox.askyesnocancel(

            "Modifications non enregistrees",

            "Voulez-vous enregistrer les modifications ?"

        )

        if reponse is None:

            return False

        if reponse:

            return self.enregistrer_fichier()

        return True

    def nouveau_fichier(self):

        if not self._confirmer_modifications():

            return

        self.editeur.delete(

            "1.0",

            tk.END

        )

        self.fichier_actuel = None

        self.modifie = False

        self.donnees = None

        self.label_fichier.configure(

            text="Nouveau fichier"

        )

        self._vider_tableau()

        self._actualiser_statistiques(None)

        self._afficher_erreurs([])

        self._changer_statut(

            "Nouveau document pret."

        )

        self._actualiser_gouttiere()

        self._colorier_syntaxe()

    def ouvrir_fichier(self):

        if not self._confirmer_modifications():

            return

        chemin = filedialog.askopenfilename(

            title="Ouvrir un fichier SGN",

            filetypes=[

                ("Fichiers SGN", "*.sgn"),

                ("Tous les fichiers", "*.*")

            ]

        )

        if not chemin:

            return

        try:

            contenu = Path(chemin).read_text(

                encoding="utf-8"

            )

            self.editeur.delete(

                "1.0",

                tk.END

            )

            self.editeur.insert(

                "1.0",

                contenu

            )

            self.fichier_actuel = Path(chemin)

            self.modifie = False

            self.donnees = None

            self.label_fichier.configure(

                text=self.fichier_actuel.name

            )

            self._vider_tableau()

            self._actualiser_statistiques(None)

            self._afficher_erreurs([])

            self._actualiser_gouttiere()

            self._colorier_syntaxe()

            self._changer_statut(

                "Fichier charge avec succes."

            )

        except (OSError, UnicodeError) as erreur:

            messagebox.showerror(

                "Erreur d'ouverture",

                str(erreur)

            )

    def enregistrer_fichier(self):

        if self.fichier_actuel is None:

            chemin = filedialog.asksaveasfilename(

                title="Enregistrer le fichier SGN",

                defaultextension=".sgn",

                filetypes=[

                    ("Fichiers SGN", "*.sgn")

                ]

            )

            if not chemin:

                return False

            self.fichier_actuel = Path(chemin)

        try:

            contenu = self.editeur.get(

                "1.0",

                "end-1c"

            )

            self.fichier_actuel.write_text(

                contenu,

                encoding="utf-8"

            )

            self.modifie = False

            self.label_fichier.configure(

                text=self.fichier_actuel.name

            )

            self._changer_statut(

                "Fichier enregistre avec succes."

            )

            return True

        except OSError as erreur:

            messagebox.showerror(

                "Erreur d'enregistrement",

                str(erreur)

            )

            return False

    def _fermer_application(self):

        if not self._confirmer_modifications():

            return

        self.fenetre.destroy()

    # =================================================

    # ANALYSE DU FICHIER

    # =================================================

    def lancer_analyse(self):

        if self.analyse_en_cours:

            return

        contenu = self.editeur.get(

            "1.0",

            "end-1c"

        )

        if not contenu.strip():

            messagebox.showwarning(

                "Fichier vide",

                "Veuillez ouvrir ou saisir un fichier SGN."

            )

            return

        self.analyse_en_cours = True

        self.bouton_analyser.configure(

            state=tk.DISABLED,

            text="Analyse en cours..."

        )

        self._changer_statut(

            "Le compilateur analyse votre fichier...",

            "analyse"

        )

        def travailleur():

            try:

                resultat = analyser_texte(contenu)

                self.fenetre.after(

                    0,

                    lambda resultat=resultat:

                    self._analyse_terminee(resultat)

                )

            except Exception as erreur:

                self.fenetre.after(

                    0,

                    lambda erreur=erreur:

                    self._analyse_echouee(erreur)

                )

        threading.Thread(

            target=travailleur,

            daemon=True

        ).start()

    def _analyse_terminee(self, resultat):

        self.analyse_en_cours = False

        self.bouton_analyser.configure(

            state=tk.NORMAL,

            text="▶  Analyser"

        )

        donnees, code_retour, diagnostic = resultat

        self.donnees = donnees

        erreurs = donnees.get(

            "erreurs",

            []

        )

        self._remplir_tableau(donnees)

        self._actualiser_statistiques(donnees)

        self._afficher_erreurs(erreurs, diagnostic)

        self.bouton_csv.configure(

            state=tk.NORMAL

        )

        self.bouton_txt.configure(

            state=tk.NORMAL

        )

        if not erreurs and code_retour == 0:

            self._changer_statut(

                "Analyse terminee : fichier SGN valide.",

                "succes"

            )

        elif erreurs:

            self._changer_statut(

                f"Analyse terminee : {len(erreurs)} erreur(s) detectee(s).",

                "erreur"

            )

        else:

            self._changer_statut(

                "Le compilateur a rencontre un probleme.",

                "erreur"

            )

    def _analyse_echouee(self, erreur):

        self.analyse_en_cours = False

        self.bouton_analyser.configure(

            state=tk.NORMAL,

            text="▶  Analyser"

        )

        self._changer_statut(

            "Impossible de terminer l'analyse.",

            "erreur"

        )

        messagebox.showerror(

            "Erreur du compilateur",

            str(erreur)

        )

    # =================================================

    # EXPORT CSV

    # =================================================

    def exporter_fichier_csv(self):

        if self.donnees is None:

            messagebox.showwarning(

                "Exportation impossible",

                "Veuillez analyser un fichier d'abord."

            )

            return

        chemin = filedialog.asksaveasfilename(

            title="Exporter les resultats en CSV",

            defaultextension=".csv",

            filetypes=[

                ("Fichier CSV", "*.csv")

            ]

        )

        if not chemin:

            return

        try:

            exporter_csv(

                chemin,

                self.donnees

            )

            fichier_ouvert = ouvrir_fichier_exporte(chemin)

            message = "Le fichier CSV a bien ete enregistre."
            if fichier_ouvert:
                message += "\nIl vient de s'ouvrir automatiquement."
            else:
                message += (
                    "\nL'ouverture automatique n'a pas fonctionne. "
                    "Vous pouvez ouvrir le fichier depuis son emplacement."
                )

            messagebox.showinfo(

                "Exportation reussie",

                message

            )

            self._changer_statut(

                "Exportation CSV terminee."

            )

        except OSError as erreur:

            messagebox.showerror(

                "Erreur CSV",

                str(erreur)

            )

    # =================================================

    # EXPORT TXT

    # =================================================

    def exporter_fichier_txt(self):

        if self.donnees is None:

            messagebox.showwarning(

                "Exportation impossible",

                "Veuillez analyser un fichier d'abord."

            )

            return

        chemin = filedialog.asksaveasfilename(

            title="Exporter les resultats en TXT",

            defaultextension=".txt",

            filetypes=[

                ("Fichier TXT", "*.txt")

            ]

        )

        if not chemin:

            return

        try:

            exporter_txt(

                chemin,

                self.donnees

            )

            fichier_ouvert = ouvrir_fichier_exporte(chemin)

            message = "Le fichier TXT a bien ete enregistre."
            if fichier_ouvert:
                message += "\nIl vient de s'ouvrir automatiquement."
            else:
                message += (
                    "\nL'ouverture automatique n'a pas fonctionne. "
                    "Vous pouvez ouvrir le fichier depuis son emplacement."
                )

            messagebox.showinfo(

                "Exportation reussie",

                message

            )

            self._changer_statut(

                "Exportation TXT terminee."

            )

        except OSError as erreur:

            messagebox.showerror(

                "Erreur TXT",

                str(erreur)

            )

# =====================================================

# LANCEMENT DE L'APPLICATION

# =====================================================

def lancer_application():

    fenetre = tk.Tk()

    # Force le catalogue de traduction francais de Tkinter.
    # Cela traduit aussi les boutons des fenetres systeme :
    # Ouvrir, Annuler, Oui, Non, Enregistrer, etc.
    try:
        fenetre.tk.call("::msgcat::mclocale", "fr")
    except tk.TclError:
        # L'application reste utilisable si le catalogue n'est pas disponible.
        pass

    SGNApplication(fenetre)

    fenetre.mainloop()

if __name__ == "__main__":

    lancer_application()
