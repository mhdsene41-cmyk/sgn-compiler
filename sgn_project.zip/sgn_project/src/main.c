
#include <stdio.h>

#include "ast.h"
#include "erreurs.h"

int yyparse(void);

extern Programme *racine;

int main(void)
{
    /* Etape 1 : analyse syntaxique */
    int resultat_parse = yyparse();

    if (resultat_parse != 0 && erreurs_nombre() == 0) {
        erreurs_ajouter(
            "syntaxique",
            0,
            "Echec de l'analyse syntaxique."
        );
    }

    /* Etape 2 : verification semantique */
    if (resultat_parse == 0 &&
        racine != NULL &&
        erreurs_nombre() == 0) {

        ast_verifier_semantique(racine);
    }

    /* Etape 3 : calcul des resultats */
    int resultats_valides =
        (resultat_parse == 0 &&
         racine != NULL &&
         erreurs_nombre() == 0);

    if (resultats_valides) {
        ast_calculer_resultats(racine);
    }

    /*
     * Etape 4 : generation JSON
     * stdout contient uniquement le JSON.
     */
    ast_ecrire_json(racine, stdout, resultats_valides);

    /* Liberation de la memoire */
    ast_liberer_programme(racine);
    erreurs_liberer();

    /* Code de retour */
    if (resultats_valides)
        return 0;

    return 1;
}
