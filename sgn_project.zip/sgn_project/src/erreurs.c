
#include "erreurs.h"

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

/* Structure interne d'une erreur */
typedef struct Erreur {
    char *type;
    int ligne;
    char *message;
    struct Erreur *suivante;
} Erreur;

/* Debut et fin de la liste */
static Erreur *debut = NULL;
static Erreur *fin = NULL;

static int nombre_erreurs = 0;

/* Copier une chaine */
static char *copier_texte(const char *texte)
{
    size_t taille = strlen(texte) + 1;

    char *copie = malloc(taille);

    if (copie == NULL) {
        fprintf(stderr, "Erreur memoire.\n");
        exit(EXIT_FAILURE);
    }

    memcpy(copie, texte, taille);

    return copie;
}

/* Ajouter une erreur */
void erreurs_ajouter(const char *type,
                     int ligne,
                     const char *message)
{
    Erreur *nouvelle = calloc(1, sizeof(Erreur));

    if (nouvelle == NULL) {
        fprintf(stderr, "Erreur memoire.\n");
        exit(EXIT_FAILURE);
    }

    nouvelle->type = copier_texte(type);
    nouvelle->ligne = ligne;
    nouvelle->message = copier_texte(message);

    if (debut == NULL) {
        debut = nouvelle;
    } else {
        fin->suivante = nouvelle;
    }

    fin = nouvelle;
    nombre_erreurs++;
}

/* Retourner le nombre d'erreurs */
int erreurs_nombre(void)
{
    return nombre_erreurs;
}

/* Ecrire une chaine correctement au format JSON */
void erreurs_ecrire_chaine_json(FILE *sortie,
                                const char *texte)
{
    const unsigned char *p =
        (const unsigned char *)(texte ? texte : "");

    fputc('"', sortie);

    while (*p) {
        switch (*p) {

            case '"':
                fputs("\\\"", sortie);
                break;

            case '\\':
                fputs("\\\\", sortie);
                break;

            case '\n':
                fputs("\\n", sortie);
                break;

            case '\r':
                fputs("\\r", sortie);
                break;

            case '\t':
                fputs("\\t", sortie);
                break;

            case '\b':
                fputs("\\b", sortie);
                break;

            case '\f':
                fputs("\\f", sortie);
                break;

            default:
                if (*p < 0x20) {
                    fprintf(sortie, "\\u%04x", *p);
                } else {
                    fputc(*p, sortie);
                }
        }

        p++;
    }

    fputc('"', sortie);
}

/* Ecrire la liste des erreurs en JSON */
void erreurs_ecrire_json(FILE *sortie)
{
    fputc('[', sortie);

    int premiere = 1;

    for (Erreur *e = debut; e != NULL; e = e->suivante) {

        if (!premiere)
            fputc(',', sortie);

        fprintf(sortie, "\n      {\"type\": ");

        erreurs_ecrire_chaine_json(sortie, e->type);

        fprintf(sortie, ", \"ligne\": %d, \"message\": ",
                e->ligne);

        erreurs_ecrire_chaine_json(sortie, e->message);

        fputs("}", sortie);

        premiere = 0;
    }

    if (!premiere)
        fputc('\n', sortie);

    fputc(']', sortie);
}

/* Liberer la liste des erreurs */
void erreurs_liberer(void)
{
    Erreur *e = debut;

    while (e != NULL) {
        Erreur *suivante = e->suivante;

        free(e->type);
        free(e->message);
        free(e);

        e = suivante;
    }

    debut = NULL;
    fin = NULL;
    nombre_erreurs = 0;
}
