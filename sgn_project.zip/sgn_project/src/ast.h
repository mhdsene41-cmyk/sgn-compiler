#ifndef AST_H
#define AST_H

#include <stdio.h>

/* Structures constituant l'arbre syntaxique abstrait du SGN. */
typedef struct Module {
    char *nom;
    long coefficient;
    double note;
    int ligne;
    struct Module *suivant;
} Module;

typedef struct Semestre {
    char *id;
    Module *modules;
    double moyenne;
    int ligne;
    struct Semestre *suivant;
} Semestre;

typedef struct Etudiant {
    char *matricule;
    char *nom;
    char *prenom;
    Semestre *semestres;

    double moyenne_annuelle;
    int rang;
    int ligne;

    const char *mention;
    const char *decision;

    struct Etudiant *suivant;
} Etudiant;

typedef struct Niveau {
    char *id;
    Etudiant *etudiants;
    struct Niveau *suivant;
} Niveau;

typedef struct Programme {
    char *annee;
    Niveau *niveaux;
} Programme;

/* Creation des elements de l'AST. */
char *ast_copier_chaine(const char *texte);

Module *ast_creer_module(char *nom, long coef,
                         double note, int ligne);

Semestre *ast_creer_semestre(char *id, Module *modules,
                             int ligne);

Etudiant *ast_creer_etudiant(char *matricule, char *nom,
                             char *prenom, Semestre *semestres,
                             int ligne);

Niveau *ast_creer_niveau(char *id, Etudiant *etudiants);

Programme *ast_creer_programme(char *annee, Niveau *niveaux);

/* Ajout d'elements dans les listes chainees. */
Module *ast_ajouter_module(Module *liste, Module *nouveau);

Semestre *ast_ajouter_semestre(Semestre *liste,
                               Semestre *nouveau);

Etudiant *ast_ajouter_etudiant(Etudiant *liste,
                               Etudiant *nouveau);

Niveau *ast_ajouter_niveau(Niveau *liste, Niveau *nouveau);

/* Liberation complete des listes, notamment lors d'une erreur Bison. */
void ast_liberer_modules(Module *modules);
void ast_liberer_semestres(Semestre *semestres);
void ast_liberer_etudiants(Etudiant *etudiants);
void ast_liberer_niveaux(Niveau *niveaux);

/* Affichage et liberation du programme complet. */
void ast_afficher_resume(const Programme *programme);
void ast_liberer_programme(Programme *programme);

/* Analyse semantique. */
int ast_verifier_semantique(const Programme *programme);

/* Calcul des moyennes, rangs et decisions. */
void ast_calculer_resultats(Programme *programme);

/* Generation du JSON consomme par l'interface Python. */
void ast_ecrire_json(const Programme *programme,
                     FILE *sortie,
                     int resultats_valides);

#endif
