
%option noyywrap yylineno noinput nounput

%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "parser.tab.h"
#include "erreurs.h"

extern YYLTYPE yylloc;

#define YY_USER_ACTION \
    do { \
        yylloc.first_line = yylineno; \
        yylloc.last_line = yylineno; \
        yylloc.first_column = 1; \
        yylloc.last_column = yyleng; \
    } while (0);
%}

CHIFFRE [0-9]
REEL {CHIFFRE}+\.{CHIFFRE}+
ENTIER {CHIFFRE}+
CHAINE \"[^\"\n]*\"
MOT [A-Za-z_][A-Za-z0-9_]*

%%

[ \t\r]+ {
}

\n {
}

"--"[^\n]* {
}

"ANNEE"    { return T_ANNEE; }
"NIVEAU"   { return T_NIVEAU; }
"ETUDIANT" { return T_ETUDIANT; }

"MATRICULE" { return T_MATRICULE; }
"NOM"       { return T_NOM; }
"PRENOM"    { return T_PRENOM; }

"SEMESTRE" { return T_SEMESTRE; }
"MODULE"   { return T_MODULE; }
"COEF"     { return T_COEF; }
"NOTE"     { return T_NOTE; }

"L1" { return T_L1; }
"L2" { return T_L2; }
"L3" { return T_L3; }

"S1" { return T_S1; }
"S2" { return T_S2; }
"S3" { return T_S3; }
"S4" { return T_S4; }
"S5" { return T_S5; }
"S6" { return T_S6; }

{CHAINE} {
    size_t longueur = (size_t)yyleng - 2;

    yylval.chaine = malloc(longueur + 1);

    if (yylval.chaine == NULL) {
        fprintf(stderr, "Erreur : memoire insuffisante.\n");
        exit(EXIT_FAILURE);
    }

    memcpy(yylval.chaine, yytext + 1, longueur);
    yylval.chaine[longueur] = '\0';

    return T_STRING;
}

{REEL} {
    yylval.reel = strtod(yytext, NULL);
    return T_REEL;
}

{ENTIER} {
    yylval.entier = strtol(yytext, NULL, 10);
    return T_ENTIER;
}

"{" { return '{'; }
"}" { return '}'; }
":" { return ':'; }

\"[^\"\n]* {
    erreurs_ajouter(
        "lexicale",
        yylineno,
        "Chaine de caracteres non terminee."
    );
}

{MOT} {
    char message[512];

    snprintf(message, sizeof(message),
             "Mot inconnu : '%s'.", yytext);

    erreurs_ajouter("lexicale", yylineno, message);
}

. {
    char message[512];

    snprintf(message, sizeof(message),
             "Caractere inattendu : '%s'.", yytext);

    erreurs_ajouter("lexicale", yylineno, message);
}

%%
