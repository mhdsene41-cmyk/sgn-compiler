/*
 * Projet SGN - Analyseur syntaxique et semantique Bison
 * Auteur : a completer par l'etudiant
 * Date : 22/11/2026
 *
 * Le parseur construit un AST a partir du langage .sgn.
 * Des points de synchronisation permettent a Bison de reprendre
 * l'analyse apres certaines erreurs de syntaxe.
 */

%code requires {
    #include "ast.h"
}

%{
#include <stdio.h>
#include <stdlib.h>

#include "ast.h"
#include "erreurs.h"

extern int yylex(void);
extern int yylineno;

void yyerror(const char *message);

Programme *racine = NULL;
%}

%define parse.error detailed
%locations

%union {
    char *chaine;
    long entier;
    double reel;

    Module *module;
    Semestre *semestre;
    Etudiant *etudiant;
    Niveau *niveau;
}

%token T_ANNEE T_NIVEAU T_ETUDIANT
%token T_MATRICULE T_NOM T_PRENOM
%token T_SEMESTRE T_MODULE T_COEF T_NOTE

%token T_L1 T_L2 T_L3
%token T_S1 T_S2 T_S3 T_S4 T_S5 T_S6

%token <chaine> T_STRING
%token <entier> T_ENTIER
%token <reel> T_REEL

%type <chaine> id_niveau id_sem
%type <reel> valeur_note

%type <module> module contenu_module liste_modules contenu_semestre
%type <semestre> semestre liste_semestres
%type <etudiant> etudiant corps_etudiant liste_etudiants
%type <niveau> niveau corps_niveau liste_niveaux

/*
 * Liberation des valeurs abandonnees par Bison pendant la recuperation.
 * Les listes AST sont chaines : chaque fonction libere toute la liste.
 */
%destructor { free($$); } <chaine>
%destructor { ast_liberer_modules($$); } <module>
%destructor { ast_liberer_semestres($$); } <semestre>
%destructor { ast_liberer_etudiants($$); } <etudiant>
%destructor { ast_liberer_niveaux($$); } <niveau>

%start programme

%%

programme:
    T_ANNEE T_STRING liste_niveaux
    {
        racine = ast_creer_programme($2, $3);
    }
    ;

/* Liste des niveaux. En cas d'erreur dans un niveau, le parseur peut
 * ignorer le bloc incorrect et reprendre au prochain mot-cle NIVEAU. */
liste_niveaux:
      niveau
      {
          $$ = $1;
      }
    | liste_niveaux niveau
      {
          $$ = ast_ajouter_niveau($1, $2);
      }
    | liste_niveaux error T_NIVEAU corps_niveau
      {
          yyerrok;
          $$ = ast_ajouter_niveau($1, $4);
      }
    | error T_NIVEAU corps_niveau
      {
          yyerrok;
          $$ = $3;
      }
    ;

niveau:
    T_NIVEAU corps_niveau
    {
        $$ = $2;
    }
    ;

corps_niveau:
    id_niveau '{' liste_etudiants '}'
    {
        $$ = ast_creer_niveau($1, $3);
    }
    ;

id_niveau:
      T_L1 { $$ = ast_copier_chaine("L1"); }
    | T_L2 { $$ = ast_copier_chaine("L2"); }
    | T_L3 { $$ = ast_copier_chaine("L3"); }
    ;

/* Liste des etudiants. T_ETUDIANT est un point de synchronisation
 * unique : apres une fiche incorrecte, la suivante peut etre analysee. */
liste_etudiants:
      etudiant
      {
          $$ = $1;
      }
    | liste_etudiants etudiant
      {
          $$ = ast_ajouter_etudiant($1, $2);
      }
    | liste_etudiants error T_ETUDIANT corps_etudiant
      {
          yyerrok;
          $$ = ast_ajouter_etudiant($1, $4);
      }
    | error T_ETUDIANT corps_etudiant
      {
          yyerrok;
          $$ = $3;
      }
    ;

etudiant:
    T_ETUDIANT corps_etudiant
    {
        $$ = $2;
    }
    ;

corps_etudiant:
    '{'
    T_MATRICULE ':' T_STRING
    T_NOM ':' T_STRING
    T_PRENOM ':' T_STRING
    liste_semestres '}'
    {
        $$ = ast_creer_etudiant(
            $4, $7, $10, $11, @2.first_line
        );
    }
    ;

liste_semestres:
      semestre
      {
          $$ = $1;
      }
    | liste_semestres semestre
      {
          $$ = ast_ajouter_semestre($1, $2);
      }
    ;

semestre:
    T_SEMESTRE id_sem '{' contenu_semestre
    {
        $$ = ast_creer_semestre(
            $2, $4, @1.first_line
        );
    }
    ;

/* Le contenu du semestre inclut son accolade de fermeture.
 * Cela permet aussi de recuperer une erreur situee dans le dernier module. */
contenu_semestre:
      liste_modules '}'
      {
          $$ = $1;
      }
    | error '}'
      {
          yyerrok;
          $$ = NULL;
      }
    ;

id_sem:
      T_S1 { $$ = ast_copier_chaine("S1"); }
    | T_S2 { $$ = ast_copier_chaine("S2"); }
    | T_S3 { $$ = ast_copier_chaine("S3"); }
    | T_S4 { $$ = ast_copier_chaine("S4"); }
    | T_S5 { $$ = ast_copier_chaine("S5"); }
    | T_S6 { $$ = ast_copier_chaine("S6"); }
    ;

/* Dans un semestre, chaque module commence par T_MODULE.
 * Apres une erreur, Bison ignore les elements incorrects jusqu'au prochain
 * T_MODULE, puis analyse le reste du module. On ne remet pas yyerrok avant
 * d'avoir atteint ce point de synchronisation. */
liste_modules:
      module
      {
          $$ = $1;
      }
    | liste_modules module
      {
          $$ = ast_ajouter_module($1, $2);
      }
    | liste_modules error T_MODULE contenu_module
      {
          yyerrok;
          $$ = ast_ajouter_module($1, $4);
      }
    | error T_MODULE contenu_module
      {
          yyerrok;
          $$ = $3;
      }
    ;

module:
    T_MODULE contenu_module
    {
        $$ = $2;
        if ($$ != NULL)
            $$->ligne = @1.first_line;
    }
    ;

contenu_module:
    T_STRING T_COEF T_ENTIER T_NOTE valeur_note
    {
        $$ = ast_creer_module(
            $1, $3, $5, @1.first_line
        );
    }
    ;

valeur_note:
      T_ENTIER { $$ = (double)$1; }
    | T_REEL   { $$ = $1; }
    ;

%%

void yyerror(const char *message)
{
    int ligne = yylloc.first_line;

    if (ligne <= 0)
        ligne = yylineno;

    erreurs_ajouter("syntaxique", ligne, message);
}
