#ifndef SYMBOLES_H
#define SYMBOLES_H

/*
 * Projet SGN
 *
 * Ce fichier est conserve pour respecter l'organisation
 * de reference definie dans le sujet du projet.
 *
 * Le projet utilise un arbre syntaxique abstrait (AST),
 * defini dans ast.h et implemente dans ast.c.
 * La table des symboles n'est donc pas utilisee.
 */

#endif
