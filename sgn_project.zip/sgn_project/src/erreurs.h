
#ifndef ERREURS_H
#define ERREURS_H

#include <stdio.h>

/* Ajouter une erreur */
void erreurs_ajouter(const char *type,
                     int ligne,
                     const char *message);

/* Connaitre le nombre d'erreurs */
int erreurs_nombre(void);

/* Ecrire les erreurs au format JSON */
void erreurs_ecrire_json(FILE *sortie);

/* Echapper une chaine pour le format JSON */
void erreurs_ecrire_chaine_json(FILE *sortie,
                                const char *texte);

/* Liberer les erreurs */
void erreurs_liberer(void);

#endif
