/*
 * Projet SGN - Gestion de l'arbre syntaxique abstrait
 * Auteur : a completer par l'etudiant
 * Date : 22/11/2026
 *
 * Ce fichier contient la creation, la manipulation, la liberation,
 * les verifications semantiques et la generation JSON de l'AST.
 */

#include "ast.h"
#include "erreurs.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* =====================================================
   1. GESTION DE LA MEMOIRE
   ===================================================== */

static void *ast_allouer(size_t taille)
{
    void *p = calloc(1, taille);

    if (p == NULL) {
        fprintf(stderr, "Erreur : memoire insuffisante.\n");
        exit(EXIT_FAILURE);
    }

    return p;
}

char *ast_copier_chaine(const char *texte)
{
    size_t taille = strlen(texte) + 1;
    char *copie = ast_allouer(taille);

    memcpy(copie, texte, taille);

    return copie;
}

/* =====================================================
   2. CREATION DES ELEMENTS DE L'AST
   ===================================================== */

Module *ast_creer_module(char *nom, long coef,
                         double note, int ligne)
{
    Module *m = ast_allouer(sizeof(Module));

    m->nom = nom;
    m->coefficient = coef;
    m->note = note;
    m->ligne = ligne;

    return m;
}

Semestre *ast_creer_semestre(char *id, Module *modules,
                             int ligne)
{
    Semestre *s = ast_allouer(sizeof(Semestre));

    s->id = id;
    s->modules = modules;
    s->ligne = ligne;

    return s;
}

Etudiant *ast_creer_etudiant(char *matricule, char *nom,
                             char *prenom, Semestre *semestres,
                             int ligne)
{
    Etudiant *e = ast_allouer(sizeof(Etudiant));

    e->matricule = matricule;
    e->nom = nom;
    e->prenom = prenom;
    e->semestres = semestres;
    e->ligne = ligne;

    return e;
}

Niveau *ast_creer_niveau(char *id, Etudiant *etudiants)
{
    Niveau *n = ast_allouer(sizeof(Niveau));

    n->id = id;
    n->etudiants = etudiants;

    return n;
}

Programme *ast_creer_programme(char *annee, Niveau *niveaux)
{
    Programme *p = ast_allouer(sizeof(Programme));

    p->annee = annee;
    p->niveaux = niveaux;

    return p;
}

/* =====================================================
   3. AJOUT DANS LES LISTES
   ===================================================== */

Module *ast_ajouter_module(Module *liste, Module *nouveau)
{
    if (liste == NULL)
        return nouveau;

    Module *p = liste;

    while (p->suivant != NULL)
        p = p->suivant;

    p->suivant = nouveau;
    return liste;
}

Semestre *ast_ajouter_semestre(Semestre *liste,
                               Semestre *nouveau)
{
    if (liste == NULL)
        return nouveau;

    Semestre *p = liste;

    while (p->suivant != NULL)
        p = p->suivant;

    p->suivant = nouveau;
    return liste;
}

Etudiant *ast_ajouter_etudiant(Etudiant *liste,
                               Etudiant *nouveau)
{
    if (liste == NULL)
        return nouveau;

    Etudiant *p = liste;

    while (p->suivant != NULL)
        p = p->suivant;

    p->suivant = nouveau;
    return liste;
}

Niveau *ast_ajouter_niveau(Niveau *liste, Niveau *nouveau)
{
    if (liste == NULL)
        return nouveau;

    Niveau *p = liste;

    while (p->suivant != NULL)
        p = p->suivant;

    p->suivant = nouveau;
    return liste;
}

/* =====================================================
   4. AFFICHAGE DE L'AST
   ===================================================== */

static void ast_afficher_branche(const char *prefixe,
                                 int dernier,
                                 const char *texte)
{
    printf("%s%s%s\n",
           prefixe,
           dernier ? "└── " : "├── ",
           texte);
}

static void ast_construire_prefixe(char *destination,
                                   size_t taille,
                                   const char *prefixe,
                                   int dernier)
{
    snprintf(destination, taille, "%s%s",
             prefixe,
             dernier ? "    " : "│   ");
}

static void ast_afficher_modules(const Module *modules,
                                 const char *prefixe)
{
    for (const Module *m = modules;
         m != NULL; m = m->suivant) {

        char texte[512];

        snprintf(texte, sizeof(texte),
                 "Module : %s (coef = %ld, note = %.2f)",
                 m->nom, m->coefficient, m->note);

        ast_afficher_branche(prefixe,
                             m->suivant == NULL,
                             texte);
    }
}

static void ast_afficher_semestres(const Semestre *semestres,
                                   const char *prefixe)
{
    for (const Semestre *s = semestres;
         s != NULL; s = s->suivant) {

        char texte[256];
        char nouveau_prefixe[1024];

        snprintf(texte, sizeof(texte),
                 "Semestre : %s", s->id);

        ast_afficher_branche(prefixe,
                             s->suivant == NULL,
                             texte);

        ast_construire_prefixe(nouveau_prefixe,
                               sizeof(nouveau_prefixe),
                               prefixe,
                               s->suivant == NULL);

        ast_afficher_modules(s->modules, nouveau_prefixe);
    }
}

static void ast_afficher_etudiants(const Etudiant *etudiants,
                                   const char *prefixe)
{
    for (const Etudiant *e = etudiants;
         e != NULL; e = e->suivant) {

        char texte[512];
        char nouveau_prefixe[1024];

        ast_afficher_branche(prefixe,
                             e->suivant == NULL,
                             "Etudiant");

        ast_construire_prefixe(nouveau_prefixe,
                               sizeof(nouveau_prefixe),
                               prefixe,
                               e->suivant == NULL);

        snprintf(texte, sizeof(texte),
                 "Matricule : %s", e->matricule);
        ast_afficher_branche(nouveau_prefixe, 0, texte);

        snprintf(texte, sizeof(texte),
                 "Nom : %s", e->nom);
        ast_afficher_branche(nouveau_prefixe, 0, texte);

        snprintf(texte, sizeof(texte),
                 "Prenom : %s", e->prenom);

        ast_afficher_branche(nouveau_prefixe,
                             e->semestres == NULL,
                             texte);

        if (e->semestres != NULL) {
            ast_afficher_semestres(e->semestres,
                                   nouveau_prefixe);
        }
    }
}

static void ast_afficher_niveaux(const Niveau *niveaux,
                                 const char *prefixe)
{
    for (const Niveau *n = niveaux;
         n != NULL; n = n->suivant) {

        char texte[256];
        char nouveau_prefixe[1024];

        snprintf(texte, sizeof(texte),
                 "Niveau : %s", n->id);

        ast_afficher_branche(prefixe,
                             n->suivant == NULL,
                             texte);

        ast_construire_prefixe(nouveau_prefixe,
                               sizeof(nouveau_prefixe),
                               prefixe,
                               n->suivant == NULL);

        ast_afficher_etudiants(n->etudiants, nouveau_prefixe);
    }
}

void ast_afficher_resume(const Programme *programme)
{
    if (programme == NULL)
        return;

    printf("\n========== ARBRE SYNTAXIQUE ABSTRAIT ==========\n\n");
    printf("Programme SGN\n");

    char texte[256];

    snprintf(texte, sizeof(texte),
             "Annee academique : %s", programme->annee);

    ast_afficher_branche("",
                         programme->niveaux == NULL,
                         texte);

    if (programme->niveaux != NULL)
        ast_afficher_niveaux(programme->niveaux, "");

    printf("\n================================================\n");
}

/* =====================================================
   5. LIBERATION DE L'AST
   ===================================================== */

void ast_liberer_modules(Module *modules)
{
    while (modules != NULL) {
        Module *suivant = modules->suivant;
        free(modules->nom);
        free(modules);
        modules = suivant;
    }
}

void ast_liberer_semestres(Semestre *semestres)
{
    while (semestres != NULL) {
        Semestre *suivant = semestres->suivant;
        ast_liberer_modules(semestres->modules);
        free(semestres->id);
        free(semestres);
        semestres = suivant;
    }
}

void ast_liberer_etudiants(Etudiant *etudiants)
{
    while (etudiants != NULL) {
        Etudiant *suivant = etudiants->suivant;
        ast_liberer_semestres(etudiants->semestres);
        free(etudiants->matricule);
        free(etudiants->nom);
        free(etudiants->prenom);
        free(etudiants);
        etudiants = suivant;
    }
}

void ast_liberer_niveaux(Niveau *niveaux)
{
    while (niveaux != NULL) {
        Niveau *suivant = niveaux->suivant;
        ast_liberer_etudiants(niveaux->etudiants);
        free(niveaux->id);
        free(niveaux);
        niveaux = suivant;
    }
}

void ast_liberer_programme(Programme *programme)
{
    if (programme == NULL)
        return;

    ast_liberer_niveaux(programme->niveaux);
    free(programme->annee);
    free(programme);
}

/* =====================================================
   6. VERIFICATIONS SEMANTIQUES
   ===================================================== */

static int semestre_autorise(const char *niveau,
                             const char *semestre)
{
    if (strcmp(niveau, "L1") == 0)
        return strcmp(semestre, "S1") == 0 ||
               strcmp(semestre, "S2") == 0;

    if (strcmp(niveau, "L2") == 0)
        return strcmp(semestre, "S3") == 0 ||
               strcmp(semestre, "S4") == 0;

    if (strcmp(niveau, "L3") == 0)
        return strcmp(semestre, "S5") == 0 ||
               strcmp(semestre, "S6") == 0;

    return 0;
}

int ast_verifier_semantique(const Programme *programme)
{
    if (programme == NULL) {
        erreurs_ajouter(
            "semantique", 0,
            "Programme inexistant."
        );
        return 1;
    }

    int nombre_initial = erreurs_nombre();

    for (const Niveau *n = programme->niveaux;
         n != NULL; n = n->suivant) {

        for (const Etudiant *e = n->etudiants;
             e != NULL; e = e->suivant) {

            /* 1. Absence de doublons */
            for (const Etudiant *autre = e->suivant;
                 autre != NULL; autre = autre->suivant) {

                if (strcmp(e->matricule,
                           autre->matricule) == 0) {

                    char message[512];

                    snprintf(message, sizeof(message),
                             "Matricule '%s' duplique dans le niveau %s.",
                             e->matricule, n->id);

                    erreurs_ajouter(
                        "semantique", autre->ligne, message
                    );
                }
            }

            /* Parcours des semestres */
            for (const Semestre *s = e->semestres;
                 s != NULL; s = s->suivant) {

                /* 2. Coherence des semestres */
                if (!semestre_autorise(n->id, s->id)) {

                    char message[512];

                    snprintf(message, sizeof(message),
                             "Semestre %s interdit pour le niveau %s (matricule %s).",
                             s->id, n->id, e->matricule);

                    erreurs_ajouter(
                        "semantique", s->ligne, message
                    );
                }

                for (const Module *m = s->modules;
                     m != NULL; m = m->suivant) {

                    /* 3. Coefficient positif */
                    if (m->coefficient < 1) {

                        char message[512];

                        snprintf(message, sizeof(message),
                                 "Coefficient invalide pour le module '%s'.",
                                 m->nom);

                        erreurs_ajouter(
                            "semantique", m->ligne, message
                        );
                    }

                    /* 4. Note comprise entre 0 et 20 */
                    if (m->note < 0.0 || m->note > 20.0) {

                        char message[512];

                        snprintf(message, sizeof(message),
                                 "Note %.2f hors intervalle [0,20] pour le module '%s'.",
                                 m->note, m->nom);

                        erreurs_ajouter(
                            "semantique", m->ligne, message
                        );
                    }
                }
            }
        }
    }

    return erreurs_nombre() - nombre_initial;
}

/* =====================================================
   7. CALCUL DES MOYENNES ET DES RANGS
   ===================================================== */

void ast_calculer_resultats(Programme *programme)
{
    if (programme == NULL)
        return;

    /* Calcul des moyennes */
    for (Niveau *n = programme->niveaux;
         n != NULL; n = n->suivant) {

        for (Etudiant *e = n->etudiants;
             e != NULL; e = e->suivant) {

            double somme_moyennes = 0.0;
            int nombre_semestres = 0;

            for (Semestre *s = e->semestres;
                 s != NULL; s = s->suivant) {

                double somme_ponderee = 0.0;
                double somme_coefficients = 0.0;

                for (Module *m = s->modules;
                     m != NULL; m = m->suivant) {

                    somme_ponderee +=
                        m->coefficient * m->note;

                    somme_coefficients += m->coefficient;
                }

                s->moyenne =
                    somme_coefficients > 0.0
                    ? somme_ponderee / somme_coefficients
                    : 0.0;

                somme_moyennes += s->moyenne;
                nombre_semestres++;
            }

            e->moyenne_annuelle =
                nombre_semestres > 0
                ? somme_moyennes / nombre_semestres
                : 0.0;

            if (e->moyenne_annuelle >= 16.0) {
                e->mention = "Tres Bien";
                e->decision = "Admis";
            }
            else if (e->moyenne_annuelle >= 14.0) {
                e->mention = "Bien";
                e->decision = "Admis";
            }
            else if (e->moyenne_annuelle >= 12.0) {
                e->mention = "Assez Bien";
                e->decision = "Admis";
            }
            else if (e->moyenne_annuelle >= 10.0) {
                e->mention = "Passable";
                e->decision = "Admis";
            }
            else {
                e->mention = "—";
                e->decision = "Ajourné";
            }
        }
    }

    /* Calcul du rang dans chaque niveau */
    for (Niveau *n = programme->niveaux;
         n != NULL; n = n->suivant) {

        for (Etudiant *e = n->etudiants;
             e != NULL; e = e->suivant) {

            int rang = 1;

            for (Etudiant *autre = n->etudiants;
                 autre != NULL; autre = autre->suivant) {

                if (autre->moyenne_annuelle >
                    e->moyenne_annuelle + 1e-9) {
                    rang++;
                }
            }

            e->rang = rang;
        }
    }
}

/* =====================================================
   8. GENERATION DU JSON
   ===================================================== */

static void json_chaine(FILE *sortie, const char *texte)
{
    erreurs_ecrire_chaine_json(sortie, texte);
}

void ast_ecrire_json(const Programme *programme,
                     FILE *sortie,
                     int resultats_valides)
{
    fprintf(sortie, "{\n");

    fprintf(sortie, "  \"annee\": ");

    if (programme != NULL)
        json_chaine(sortie, programme->annee);
    else
        fprintf(sortie, "null");

    fprintf(sortie, ",\n  \"niveaux\": [");

    int premier_niveau = 1;

    if (programme != NULL) {
        for (const Niveau *n = programme->niveaux;
             n != NULL; n = n->suivant) {

            if (!premier_niveau)
                fprintf(sortie, ",");

            fprintf(sortie, "\n    {\n      \"niveau\": ");
            json_chaine(sortie, n->id);

            fprintf(sortie, ",\n      \"etudiants\": [");

            int premier_etudiant = 1;

            for (const Etudiant *e = n->etudiants;
                 e != NULL; e = e->suivant) {

                if (!premier_etudiant)
                    fprintf(sortie, ",");

                fprintf(sortie, "\n        {\n");

                fprintf(sortie, "          \"matricule\": ");
                json_chaine(sortie, e->matricule);

                fprintf(sortie, ",\n          \"nom\": ");
                json_chaine(sortie, e->nom);

                fprintf(sortie, ",\n          \"prenom\": ");
                json_chaine(sortie, e->prenom);

                fprintf(sortie, ",\n          \"semestres\": [");

                int premier_semestre = 1;

                for (const Semestre *s = e->semestres;
                     s != NULL; s = s->suivant) {

                    if (!premier_semestre)
                        fprintf(sortie, ",");

                    fprintf(sortie, "\n            {\n");
                    fprintf(sortie, "              \"id\": ");
                    json_chaine(sortie, s->id);

                    fprintf(sortie,
                            ",\n              \"modules\": [");

                    int premier_module = 1;

                    for (const Module *m = s->modules;
                         m != NULL; m = m->suivant) {

                        if (!premier_module)
                            fprintf(sortie, ",");

                        fprintf(sortie, "\n                {\"nom\": ");
                        json_chaine(sortie, m->nom);

                        fprintf(sortie,
                                ", \"coef\": %ld, \"note\": %.10g}",
                                m->coefficient, m->note);

                        premier_module = 0;
                    }

                    if (!premier_module)
                        fprintf(sortie, "\n              ");

                    fprintf(sortie, "],\n              \"moyenne\": ");

                    if (resultats_valides)
                        fprintf(sortie, "%.2f", s->moyenne);
                    else
                        fprintf(sortie, "null");

                    fprintf(sortie, "\n            }");

                    premier_semestre = 0;
                }

                if (!premier_semestre)
                    fprintf(sortie, "\n          ");

                fprintf(sortie, "],\n");

                fprintf(sortie,
                        "          \"moyenne_annuelle\": ");

                if (resultats_valides)
                    fprintf(sortie, "%.2f", e->moyenne_annuelle);
                else
                    fprintf(sortie, "null");

                fprintf(sortie, ",\n          \"mention\": ");

                if (resultats_valides)
                    json_chaine(sortie, e->mention);
                else
                    fprintf(sortie, "null");

                fprintf(sortie, ",\n          \"decision\": ");

                if (resultats_valides)
                    json_chaine(sortie, e->decision);
                else
                    fprintf(sortie, "null");

                fprintf(sortie, ",\n          \"rang\": ");

                if (resultats_valides)
                    fprintf(sortie, "%d", e->rang);
                else
                    fprintf(sortie, "null");

                fprintf(sortie, "\n        }");

                premier_etudiant = 0;
            }

            if (!premier_etudiant)
                fprintf(sortie, "\n      ");

            fprintf(sortie, "]\n    }");

            premier_niveau = 0;
        }
    }

    if (!premier_niveau)
        fprintf(sortie, "\n  ");

    fprintf(sortie, "],\n  \"erreurs\": ");

    erreurs_ecrire_json(sortie);

    fprintf(sortie, "\n}\n");
}
